GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.
    
    Strategies used:
    1. Multi-Start Greedy: Try different sorting strategies to find a good initial solution.
       - Greedy Logic: Min-Max Lookahead (choose the move that minimizes the resultant Global Max KVPR).
    2. Iterative Improvement (Local Search):
       - Moves: Relocate a model from the bottleneck GPU to another.
       - Swaps: Swap a model from the bottleneck GPU with a model on another GPU.
       - Tie-breaking: Use remaining memory variance to guide decisions when KVPR is similar.
    """
    import math

    # --- Helper Functions ---
    def get_kvpr(load, used_mem):
        remaining = GPU_MEM_SIZE - used_mem
        if remaining <= 1e-7: # Epsilon for float safety
            return float('inf')
        return load / remaining

    def calculate_global_max_kvpr(loads, used_mems):
        """Calculates the max KVPR across all GPUs given state arrays."""
        max_k = 0.0
        for i in range(len(loads)):
            k = get_kvpr(loads[i], used_mems[i])
            if k > max_k:
                max_k = k
        return max_k

    # --- Solver Logic ---
    def solve_greedy(sorted_models):
        """Generates an initial solution using Min-Max Lookahead Greedy."""
        placement = {i: [] for i in range(gpu_num)}
        gpu_load = [0.0] * gpu_num
        gpu_used = [0.0] * gpu_num
        
        # We track the current global max KVPR dynamically
        current_global_max_kvpr = 0.0

        for model in sorted_models:
            w = model.req_rate / model.slo
            s = model.model_size
            
            best_gpu = -1
            best_impact = (float('inf'), float('inf'), float('inf')) 
            # (New Global Max KVPR, Sum of KVPR, Used Memory on chosen GPU)

            # Try placing the model on every GPU
            feasible_found = False
            for i in range(gpu_num):
                if gpu_used[i] + s > GPU_MEM_SIZE:
                    continue
                
                feasible_found = True
                
                # Simulate state
                new_load = gpu_load[i] + w
                new_used = gpu_used[i] + s
                new_kvpr = get_kvpr(new_load, new_used)
                
                # Determine new global max if we place here
                # Optimization: We only need to check if new_kvpr exceeds current known max
                # or if the GPU i was previously the one defining the max (which is rare in construction phase 
                # as stats only grow).
                # Actually, simpler to just compute the impact relative to current max.
                
                projected_max = max(current_global_max_kvpr, new_kvpr)
                
                # Tie-breakers:
                # 1. Minimize Global Max KVPR
                # 2. Minimize the specific GPU's KVPR (load balancing)
                # 3. Minimize Used Memory (keep memory open for later big models)
                
                # We calculate sum of KVPRs roughly to break ties
                # (We don't need full sum, just local addition is enough for comparison usually, 
                # but let's be precise for the tuple comparison).
                # Actually, simple tie-breaker: new_kvpr itself.
                
                impact = (projected_max, new_kvpr, new_used)
                
                if impact < best_impact:
                    best_impact = impact
                    best_gpu = i

            # If no GPU fits, try to fit anywhere (best effort)
            if best_gpu == -1:
                # This usually implies input is infeasible, but we try standard First Fit
                for i in range(gpu_num):
                    if gpu_used[i] + s <= GPU_MEM_SIZE:
                        best_gpu = i
                        break
                if best_gpu == -1:
                    return None, float('inf'), [], [] # Failed

            # Commit
            placement[best_gpu].append(model)
            gpu_load[best_gpu] += w
            gpu_used[best_gpu] += s
            
            # Update global max tracker
            # It's expensive to recompute full max every time, but accurate.
            # Since we just added, the max is either the old max or the new GPU's kvpr.
            current_global_max_kvpr = max(current_global_max_kvpr, get_kvpr(gpu_load[best_gpu], gpu_used[best_gpu]))
            
        return placement, current_global_max_kvpr, gpu_load, gpu_used

    def optimize_solution(placement, current_max, gpu_load, gpu_used):
        """
        Performs local search to improve the solution.
        Focuses on the Bottleneck GPU (the one with Max KVPR).
        """
        # We run a loop until no improvement is found
        improved = True
        iterations = 0
        MAX_ITER = 500 # Cap iterations for speed

        while improved and iterations < MAX_ITER:
            improved = False
            iterations += 1
            
            # 1. Identify Bottleneck GPU(s)
            # Find the actual max and the GPU index
            current_vals = [get_kvpr(gpu_load[i], gpu_used[i]) for i in range(gpu_num)]
            global_max = max(current_vals)
            
            # Optimization: If max is 0 (empty), done.
            if global_max < 1e-9:
                break

            # Find all GPUs near the max (within epsilon)
            bottlenecks = [i for i, v in enumerate(current_vals) if v >= global_max - 1e-9]
            
            # We select one bottleneck (the first one usually suffices) to relieve pressure
            src_gpu = bottlenecks[0]
            
            # Strategy: Find a move or swap involving src_gpu that reduces global_max
            best_move = None
            # Target to beat
            best_new_global_max = global_max
            
            src_models = placement[src_gpu]
            
            # Try MOVING a model from src_gpu -> dst_gpu
            for m_idx, model in enumerate(src_models):
                w = model.req_rate / model.slo
                s = model.model_size
                
                for dst_gpu in range(gpu_num):
                    if src_gpu == dst_gpu: continue
                    if gpu_used[dst_gpu] + s > GPU_MEM_SIZE: continue
                    
                    # Calculate new states
                    # Src new state
                    src_load_new = gpu_load[src_gpu] - w
                    src_used_new = gpu_used[src_gpu] - s
                    src_kvpr_new = get_kvpr(src_load_new, src_used_new)
                    
                    # Dst new state
                    dst_load_new = gpu_load[dst_gpu] + w
                    dst_used_new = gpu_used[dst_gpu] + s
                    dst_kvpr_new = get_kvpr(dst_load_new, dst_used_new)
                    
                    # Quick check: Is the new local max already worse/same?
                    local_max = max(src_kvpr_new, dst_kvpr_new)
                    if local_max >= best_new_global_max - 1e-10:
                        continue
                    
                    # Check global impact
                    # The new global max is max(local_max, existing max of OTHER GPUs)
                    # We need the max of all GPUs excluding src and dst
                    other_max = 0.0
                    for k in range(gpu_num):
                        if k != src_gpu and k != dst_gpu:
                            if current_vals[k] > other_max:
                                other_max = current_vals[k]
                    
                    projected_global = max(local_max, other_max)
                    
                    if projected_global < best_new_global_max - 1e-10:
                        best_new_global_max = projected_global
                        best_move = ('move', m_idx, dst_gpu, w, s)

            # Try SWAPPING a model from src_gpu <-> dst_gpu
            # Only do this if moving didn't solve it optimally, or try to beat the move
            for m1_idx, m1 in enumerate(src_models):
                w1 = m1.req_rate / m1.slo
                s1 = m1.model_size
                
                for dst_gpu in range(gpu_num):
                    if src_gpu == dst_gpu: continue
                    
                    for m2_idx, m2 in enumerate(placement[dst_gpu]):
                        w2 = m2.req_rate / m2.slo
                        s2 = m2.model_size
                        
                        # Capacity Check
                        if gpu_used[src_gpu] - s1 + s2 > GPU_MEM_SIZE: continue
                        if gpu_used[dst_gpu] - s2 + s1 > GPU_MEM_SIZE: continue
                        
                        # New states
                        src_load_new = gpu_load[src_gpu] - w1 + w2
                        src_used_new = gpu_used[src_gpu] - s1 + s2
                        src_kvpr_new = get_kvpr(src_load_new, src_used_new)
                        
                        dst_load_new = gpu_load[dst_gpu] - w2 + w1
                        dst_used_new = gpu_used[dst_gpu] - s2 + s1
                        dst_kvpr_new = get_kvpr(dst_load_new, dst_used_new)
                        
                        local_max = max(src_kvpr_new, dst_kvpr_new)
                        if local_max >= best_new_global_max - 1e-10:
                            continue
                            
                        other_max = 0.0
                        for k in range(gpu_num):
                            if k != src_gpu and k != dst_gpu:
                                if current_vals[k] > other_max:
                                    other_max = current_vals[k]
                        
                        projected_global = max(local_max, other_max)
                        
                        if projected_global < best_new_global_max - 1e-10:
                            best_new_global_max = projected_global
                            best_move = ('swap', m1_idx, dst_gpu, m2_idx, w1, s1, w2, s2)

            # Execute best move
            if best_move:
                improved = True
                action = best_move[0]
                if action == 'move':
                    _, m_idx, dst, w, s = best_move
                    model = placement[src_gpu].pop(m_idx)
                    placement[dst].append(model)
                    
                    gpu_load[src_gpu] -= w
                    gpu_used[src_gpu] -= s
                    gpu_load[dst] += w
                    gpu_used[dst] += s
                elif action == 'swap':
                    _, m1_idx, dst, m2_idx, w1, s1, w2, s2 = best_move
                    model1 = placement[src_gpu][m1_idx]
                    model2 = placement[dst][m2_idx]
                    
                    placement[src_gpu][m1_idx] = model2
                    placement[dst][m2_idx] = model1
                    
                    gpu_load[src_gpu] = gpu_load[src_gpu] - w1 + w2
                    gpu_used[src_gpu] = gpu_used[src_gpu] - s1 + s2
                    gpu_load[dst] = gpu_load[dst] - w2 + w1
                    gpu_used[dst] = gpu_used[dst] - s2 + s1
        
        return placement, calculate_global_max_kvpr(gpu_load, gpu_used)

    # --- Main Execution Block ---

    # Define Sorting Strategies
    # We try a few permutations. The order matters for the Greedy pass.
    strategies = [
        # 1. High Pressure first (Hardest to place efficiently), then Size
        lambda m: (m.req_rate / m.slo, m.model_size),
        # 2. Largest Size first (Best Fit logic for packing), then Pressure
        lambda m: (m.model_size, m.req_rate / m.slo),
        # 3. Product of Pressure and Size (Overall impact metric)
        lambda m: (m.req_rate / m.slo) * m.model_size,
    ]

    best_final_placement = None
    best_final_kvpr = float('inf')

    # Deep copy wrapper to avoid modifying shared objects if any (though input is list of models)
    # The models objects themselves are just references, so we don't need deep copy for them,
    # but we need new lists for placement dicts.

    for strat_key in strategies:
        # Sort
        sorted_models = sorted(models, key=strat_key, reverse=True)
        
        # Greedy Construct
        placement, init_kvpr, g_load, g_used = solve_greedy(sorted_models)
        
        if placement is None: 
            continue # Infeasible start
            
        # Local Search Improvement
        # We work on copies of the arrays/dicts so we don't mess up if we want to revert (though here we just pick best)
        # But optimize_solution modifies in-place, which is fine as we discard if not best.
        final_placement, final_kvpr = optimize_solution(placement, init_kvpr, g_load, g_used)
        
        if final_kvpr < best_final_kvpr:
            best_final_kvpr = final_kvpr
            # Save a snapshot of the result
            best_final_placement = {k: list(v) for k, v in final_placement.items()}

    # Safety Fallback
    if best_final_placement is None:
        return {i: [] for i in range(gpu_num)}

    return best_final_placement

# EVOLVE-BLOCK-END