GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.
    
    Strategies used:
    1. Smart Sorting: Prioritize models with high pressure (req_rate/slo) and large size.
    2. Greedy Construction with Look-Ahead: Place models to minimize the projected Global Max KVPR.
    3. Tie-Breaking: Prefer GPUs with more remaining memory to accommodate future large models.
    4. Local Search: Iteratively improve the solution by moving or swapping models from the bottleneck GPU.
    """

    # 1. Sort models
    # Primary key: req_rate/slo (descending) - high pressure models are critical
    # Secondary key: model_size (descending) - large models are hard constraints
    sorted_models = sorted(models, key=lambda m: (m.req_rate / m.slo, m.model_size), reverse=True)

    # 2. Initialize tracking structures
    placement = {i: [] for i in range(gpu_num)}
    gpu_load = [0.0] * gpu_num        # Sum of req_rate / slo per GPU
    gpu_remaining_mem = [GPU_MEM_SIZE] * gpu_num

    def get_kvpr(load, mem):
        """Helper to calculate KVPR safely."""
        if mem <= 0:
            return float('inf')
        return load / mem

    # 3. Greedy Placement with Look-Ahead
    for model in sorted_models:
        w_model = model.req_rate / model.slo
        s_model = model.model_size
        
        candidates = []

        # Try placing current model on every GPU
        for gpu_idx in range(gpu_num):
            if gpu_remaining_mem[gpu_idx] >= s_model:
                # Calculate hypothetical state for this GPU
                new_local_load = gpu_load[gpu_idx] + w_model
                new_local_mem = gpu_remaining_mem[gpu_idx] - s_model
                new_local_kvpr = get_kvpr(new_local_load, new_local_mem)
                
                # Calculate the potential global max KVPR if we choose this GPU
                # It is max(new_local_kvpr, max KVPR of all other GPUs)
                current_others_max = 0.0
                for other_idx in range(gpu_num):
                    if other_idx != gpu_idx:
                        others_kvpr = get_kvpr(gpu_load[other_idx], gpu_remaining_mem[other_idx])
                        if others_kvpr > current_others_max:
                            current_others_max = others_kvpr
                
                projected_global_max = max(new_local_kvpr, current_others_max)
                candidates.append((projected_global_max, new_local_mem, gpu_idx))
        
        if not candidates:
             raise ValueError(f"Unable to place model {model.model_name} of size {s_model} GB. No GPU has enough space.")

        # Sort candidates: 
        # 1. Minimize projected global max KVPR
        # 2. Maximize remaining memory (tie-breaker) -> sort by negative mem ascending
        candidates.sort(key=lambda x: (x[0], -x[1]))
        
        best_gpu_idx = candidates[0][2]
        
        # Commit placement
        placement[best_gpu_idx].append(model)
        gpu_load[best_gpu_idx] += w_model
        gpu_remaining_mem[best_gpu_idx] -= s_model

    # 4. Local Search / Refinement
    # Attempt to alleviate the bottleneck GPU (highest KVPR) by Moving or Swapping models
    MAX_ITERATIONS = 200
    
    for _ in range(MAX_ITERATIONS):
        # Identify current bottleneck
        current_kvprs = [get_kvpr(gpu_load[i], gpu_remaining_mem[i]) for i in range(gpu_num)]
        max_kvpr = max(current_kvprs)
        
        # If max KVPR is 0 or negligible, we can't improve
        if max_kvpr < 1e-9:
            break
            
        bottleneck_gpu = current_kvprs.index(max_kvpr)
        improved_step = False
        
        bottleneck_models = placement[bottleneck_gpu]
        
        # Strategy A: Move a model from bottleneck GPU to another GPU
        for m_idx, model in enumerate(bottleneck_models):
            w = model.req_rate / model.slo
            s = model.model_size
            
            for target_gpu in range(gpu_num):
                if target_gpu == bottleneck_gpu:
                    continue
                
                # Check capacity
                if gpu_remaining_mem[target_gpu] >= s:
                    new_src_load = gpu_load[bottleneck_gpu] - w
                    new_src_mem = gpu_remaining_mem[bottleneck_gpu] + s
                    new_src_kvpr = get_kvpr(new_src_load, new_src_mem)
                    
                    new_dst_load = gpu_load[target_gpu] + w
                    new_dst_mem = gpu_remaining_mem[target_gpu] - s
                    new_dst_kvpr = get_kvpr(new_dst_load, new_dst_mem)
                    
                    # We accept the move if it strictly reduces the pressure on the two involved GPUs below the current global max
                    if max(new_src_kvpr, new_dst_kvpr) < max_kvpr - 1e-9:
                        # Execute Move
                        placement[bottleneck_gpu].pop(m_idx)
                        placement[target_gpu].append(model)
                        
                        gpu_load[bottleneck_gpu] = new_src_load
                        gpu_remaining_mem[bottleneck_gpu] = new_src_mem
                        gpu_load[target_gpu] = new_dst_load
                        gpu_remaining_mem[target_gpu] = new_dst_mem
                        
                        improved_step = True
                        break
            if improved_step: break
        
        if improved_step:
            continue
            
        # Strategy B: Swap a model from bottleneck with a model from another GPU
        for m1_idx, m1 in enumerate(bottleneck_models):
            w1 = m1.req_rate / m1.slo
            s1 = m1.model_size
            
            for target_gpu in range(gpu_num):
                if target_gpu == bottleneck_gpu: continue
                
                target_models = placement[target_gpu]
                for m2_idx, m2 in enumerate(target_models):
                    w2 = m2.req_rate / m2.slo
                    s2 = m2.model_size
                    
                    # Check memory constraints for swap:
                    # Src: gains s1 (free), loses s2 (add) -> rem + s1 - s2 >= 0
                    # Dst: gains s2 (free), loses s1 (add) -> rem + s2 - s1 >= 0
                    
                    if (gpu_remaining_mem[bottleneck_gpu] + s1 - s2 >= 0) and \
                       (gpu_remaining_mem[target_gpu] + s2 - s1 >= 0):
                        
                        new_src_load = gpu_load[bottleneck_gpu] - w1 + w2
                        new_src_mem = gpu_remaining_mem[bottleneck_gpu] + s1 - s2
                        new_src_kvpr = get_kvpr(new_src_load, new_src_mem)
                        
                        new_dst_load = gpu_load[target_gpu] - w2 + w1
                        new_dst_mem = gpu_remaining_mem[target_gpu] + s2 - s1
                        new_dst_kvpr = get_kvpr(new_dst_load, new_dst_mem)
                        
                        if max(new_src_kvpr, new_dst_kvpr) < max_kvpr - 1e-9:
                            # Execute Swap
                            placement[bottleneck_gpu][m1_idx] = m2
                            placement[target_gpu][m2_idx] = m1
                            
                            gpu_load[bottleneck_gpu] = new_src_load
                            gpu_remaining_mem[bottleneck_gpu] = new_src_mem
                            gpu_load[target_gpu] = new_dst_load
                            gpu_remaining_mem[target_gpu] = new_dst_mem
                            
                            improved_step = True
                            break
                if improved_step: break
            if improved_step: break

        if not improved_step:
            break

    return placement

# EVOLVE-BLOCK-END