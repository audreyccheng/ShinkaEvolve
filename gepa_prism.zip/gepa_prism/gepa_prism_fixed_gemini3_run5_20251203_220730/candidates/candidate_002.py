GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.
    
    Strategies used:
    1. Multi-Start: Try multiple sorting strategies (Pressure, Size, Impact) and pick the best result.
    2. Greedy with Look-Ahead: Place models to minimize projected Global Max KVPR.
    3. Tie-Breaking: Minimize Sum of KVPRs (balance) and Maximize Remaining Memory.
    4. Best-Move Local Search: Iteratively apply the single best move/swap that reduces Global Max KVPR.
    """
    
    # Helper to compute KVPR safely
    def get_kvpr(load, used_mem):
        remaining = GPU_MEM_SIZE - used_mem
        if remaining <= 1e-7: # Use epsilon for float comparison
            return float('inf')
        return load / remaining

    # Core solver function that runs one strategy
    def solve(sort_key):
        # 1. Sort models based on the provided key
        sorted_models = sorted(models, key=sort_key, reverse=True)
        
        # 2. Initialize state
        placement = {i: [] for i in range(gpu_num)}
        gpu_load = [0.0] * gpu_num  # Sum of req_rate / slo
        gpu_used = [0.0] * gpu_num  # Sum of model_size
        
        # 3. Greedy Construction
        for model in sorted_models:
            w = model.req_rate / model.slo
            s = model.model_size
            
            best_gpu = -1
            # Metric: (Projected Max KVPR, Projected Sum KVPR, Used Memory)
            # We minimize this tuple.
            best_score = (float('inf'), float('inf'), float('inf'))
            
            for i in range(gpu_num):
                # Capacity Check
                if gpu_used[i] + s > GPU_MEM_SIZE:
                    continue
                
                # Simulate placement on GPU i
                new_load_i = gpu_load[i] + w
                new_used_i = gpu_used[i] + s
                new_kvpr_i = get_kvpr(new_load_i, new_used_i)
                
                # Calculate Global Stats if we choose GPU i
                current_max = new_kvpr_i
                current_sum = new_kvpr_i
                
                for j in range(gpu_num):
                    if i == j: continue
                    # Other GPUs don't change
                    k = get_kvpr(gpu_load[j], gpu_used[j])
                    if k > current_max: current_max = k
                    current_sum += k
                
                # Score tuple: 
                # 1. Primary: Minimize Global Max KVPR
                # 2. Secondary: Minimize Sum of KVPRs (Load Balancing)
                # 3. Tertiary: Minimize Used Memory (Maximize Free Space / Worst Fit for Size)
                score = (current_max, current_sum, new_used_i)
                
                if score < best_score:
                    best_score = score
                    best_gpu = i
            
            # Fallback if no GPU is found (rare, usually means total size exceeded)
            if best_gpu == -1:
                for i in range(gpu_num):
                    if gpu_used[i] + s <= GPU_MEM_SIZE:
                        best_gpu = i
                        break
                if best_gpu == -1:
                    return None, float('inf') # Failed to place

            # Commit placement
            placement[best_gpu].append(model)
            gpu_load[best_gpu] += w
            gpu_used[best_gpu] += s

        # 4. Local Search (Steepest Descent / Best Improvement)
        # We iterate to find the move/swap that provides the BIGGEST reduction in Max KVPR
        MAX_ITER = 200
        for _ in range(MAX_ITER):
            # Current status
            current_kvprs = [get_kvpr(gpu_load[i], gpu_used[i]) for i in range(gpu_num)]
            global_max = max(current_kvprs)
            
            if global_max < 1e-9:
                break
                
            # Identify bottlenecks (GPUs with max KVPR)
            bottlenecks = [i for i, k in enumerate(current_kvprs) if k >= global_max - 1e-9]
            
            best_move = None
            # We want to find a state where the new global max is strictly less than current global_max
            best_new_max = global_max 
            
            # Scan possible moves from bottlenecks
            for src in bottlenecks:
                src_models = placement[src]
                
                # Try Moving a model
                for m_idx, m in enumerate(src_models):
                    w = m.req_rate / m.slo
                    s = m.model_size
                    
                    for dst in range(gpu_num):
                        if src == dst: continue
                        if gpu_used[dst] + s > GPU_MEM_SIZE: continue
                        
                        # Simulate Move
                        k_src_new = get_kvpr(gpu_load[src] - w, gpu_used[src] - s)
                        k_dst_new = get_kvpr(gpu_load[dst] + w, gpu_used[dst] + s)
                        
                        local_max_involved = max(k_src_new, k_dst_new)
                        
                        # Optimization: If local max of changed GPUs is already >= best_new_max, skip
                        if local_max_involved >= best_new_max - 1e-12:
                            continue
                            
                        # Calculate true global max
                        other_max = 0.0
                        for o in range(gpu_num):
                            if o != src and o != dst:
                                if current_kvprs[o] > other_max: other_max = current_kvprs[o]
                        
                        projected_global = max(local_max_involved, other_max)
                        
                        if projected_global < best_new_max - 1e-12:
                            best_new_max = projected_global
                            best_move = ('move', src, m_idx, dst, w, s)

                # Try Swapping models
                for m1_idx, m1 in enumerate(src_models):
                    w1 = m1.req_rate / m1.slo
                    s1 = m1.model_size
                    
                    for dst in range(gpu_num):
                        if src == dst: continue
                        
                        dst_models = placement[dst]
                        for m2_idx, m2 in enumerate(dst_models):
                            w2 = m2.req_rate / m2.slo
                            s2 = m2.model_size
                            
                            # Capacity check for swap
                            if gpu_used[src] - s1 + s2 > GPU_MEM_SIZE: continue
                            if gpu_used[dst] - s2 + s1 > GPU_MEM_SIZE: continue
                            
                            # Simulate Swap
                            k_src_new = get_kvpr(gpu_load[src] - w1 + w2, gpu_used[src] - s1 + s2)
                            k_dst_new = get_kvpr(gpu_load[dst] - w2 + w1, gpu_used[dst] - s2 + s1)
                            
                            local_max_involved = max(k_src_new, k_dst_new)
                            
                            if local_max_involved >= best_new_max - 1e-12:
                                continue
                                
                            other_max = 0.0
                            for o in range(gpu_num):
                                if o != src and o != dst:
                                    if current_kvprs[o] > other_max: other_max = current_kvprs[o]
                                    
                            projected_global = max(local_max_involved, other_max)
                            
                            if projected_global < best_new_max - 1e-12:
                                best_new_max = projected_global
                                best_move = ('swap', src, m1_idx, dst, m2_idx, w1, s1, w2, s2)

            # Execute best move
            if best_move:
                if best_move[0] == 'move':
                    _, s_idx, m_idx, d_idx, w, s = best_move
                    mod = placement[s_idx].pop(m_idx)
                    placement[d_idx].append(mod)
                    gpu_load[s_idx] -= w
                    gpu_used[s_idx] -= s
                    gpu_load[d_idx] += w
                    gpu_used[d_idx] += s
                else:
                    _, s_idx, m1_idx, d_idx, m2_idx, w1, s1, w2, s2 = best_move
                    mod1 = placement[s_idx][m1_idx]
                    mod2 = placement[d_idx][m2_idx]
                    placement[s_idx][m1_idx] = mod2
                    placement[d_idx][m2_idx] = mod1
                    gpu_load[s_idx] = gpu_load[s_idx] - w1 + w2
                    gpu_used[s_idx] = gpu_used[s_idx] - s1 + s2
                    gpu_load[d_idx] = gpu_load[d_idx] - w2 + w1
                    gpu_used[d_idx] = gpu_used[d_idx] - s2 + s1
            else:
                # No strict improvement found
                break
                
        return placement, global_max

    # 5. Execute Multi-Start Strategy
    # We try different sorting keys to handle heterogeneous model distributions
    strategies = [
        lambda m: (m.req_rate / m.slo, m.model_size),       # 1. Pressure Desc, Size Desc (Standard)
        lambda m: (m.model_size, m.req_rate / m.slo),       # 2. Size Desc, Pressure Desc (Fit Big Rocks)
        lambda m: ((m.req_rate / m.slo) * m.model_size),    # 3. Impact Desc (Combined Heuristic)
        lambda m: (m.req_rate / m.slo)                      # 4. Pure Pressure
    ]

    best_final_placement = None
    best_final_kvpr = float('inf')

    for strategy in strategies:
        try:
            pl, kvpr = solve(strategy)
            if pl is not None and kvpr < best_final_kvpr:
                best_final_kvpr = kvpr
                # Create a copy of the result
                best_final_placement = {k: list(v) for k, v in pl.items()}
        except Exception:
            continue

    if best_final_placement is None:
        # Fallback to an empty structure if everything fails
        return {i: [] for i in range(gpu_num)}

    return best_final_placement

# EVOLVE-BLOCK-END