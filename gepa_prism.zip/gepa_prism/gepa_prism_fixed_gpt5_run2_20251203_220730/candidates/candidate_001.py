GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.

    KVPR(gpu) = sum(req_rate/slo for models on gpu) / (GPU_MEM_SIZE - sum(model_size))
    If remaining memory is 0 or less, KVPR is treated as infinity.

    Args:
        gpu_num: Number of GPUs (0..gpu_num-1 are valid IDs)
        models: List of Model objects to place. Each Model has:
                - model_name: str
                - model_size: int (GB)
                - req_rate: int
                - slo: int
                - cur_gpu_id: int (unused here)

    Returns:
        A dict mapping gpu_id -> list[Model], with all models placed.
    """

    # Helper functions
    def weight_of(m):
        # Importance weight for KVPR numerator
        return (m.req_rate / m.slo) if m.slo != 0 else float('inf')

    def kvpr(num_w, rem_m):
        return float('inf') if rem_m <= 0 else (num_w / rem_m)

    def current_kvprs(weights, rems):
        return [kvpr(weights[i], rems[i]) for i in range(gpu_num)]

    def max_kvpr_after_add(gid, m, weights, rems):
        # If cannot fit, return infinity
        if rems[gid] < m.model_size:
            return float('inf')
        new_rem = rems[gid] - m.model_size
        new_w = weights[gid] + weight_of(m)
        max_val = 0.0
        for j in range(gpu_num):
            if j == gid:
                v = kvpr(new_w, new_rem)
            else:
                v = kvpr(weights[j], rems[j])
            if v > max_val:
                max_val = v
        return max_val

    def recompute_max_kvpr(weights, rems):
        max_val = 0.0
        for i in range(gpu_num):
            v = kvpr(weights[i], rems[i])
            if v > max_val:
                max_val = v
        return max_val

    # Sort models by (req_rate/slo) then by model_size, both descending.
    # This prioritizes "heavier" and larger models first.
    sorted_models = sorted(
        models,
        key=lambda m: (weight_of(m), m.model_size),
        reverse=True
    )

    # Initialize per-GPU states
    placement = {gpu_id: [] for gpu_id in range(gpu_num)}
    remaining_mem = [GPU_MEM_SIZE for _ in range(gpu_num)]  # remaining memory per GPU
    weights = [0.0 for _ in range(gpu_num)]                 # sum of req_rate/slo per GPU

    # Greedy placement with global look-ahead
    for m in sorted_models:
        if m.model_size > GPU_MEM_SIZE:
            raise ValueError(f"Model {m.model_name} size {m.model_size}GB exceeds GPU capacity {GPU_MEM_SIZE}GB")

        best_gpu = None
        best_key = None  # tuple for comparison

        for gid in range(gpu_num):
            if remaining_mem[gid] < m.model_size:
                continue

            new_rem = remaining_mem[gid] - m.model_size
            new_w = weights[gid] + weight_of(m)

            # Future max KVPR if we place m on gid
            future_max = 0.0
            for j in range(gpu_num):
                if j == gid:
                    v = kvpr(new_w, new_rem)
                else:
                    v = kvpr(weights[j], remaining_mem[j])
                if v > future_max:
                    future_max = v

            # Tie-breaking: prefer more remaining memory after placement,
            # then lower current weight on the target GPU, then smaller gpu_id.
            key = (future_max, -new_rem, weights[gid], gid)

            if best_key is None or key < best_key:
                best_key = key
                best_gpu = gid

        if best_gpu is None:
            # No GPU can fit this model
            raise ValueError(
                f"Unable to place model {m.model_name} of size {m.model_size} GB on any GPU. "
                f"Remaining per-GPU memory: {remaining_mem}"
            )

        placement[best_gpu].append(m)
        weights[best_gpu] += weight_of(m)
        remaining_mem[best_gpu] -= m.model_size

    # Local search: try to reduce the maximum KVPR by moving or swapping models.
    def try_improve_by_moves():
        # Attempt single-model moves from the current bottleneck GPU.
        kvprs = current_kvprs(weights, remaining_mem)
        worst_gpu = max(range(gpu_num), key=lambda i: kvprs[i])
        current_max = kvprs[worst_gpu]
        improved = False

        # Early exit if there are no models on the worst GPU
        if not placement[worst_gpu]:
            return False

        for m in placement[worst_gpu]:
            wm = weight_of(m)
            for dest in range(gpu_num):
                if dest == worst_gpu:
                    continue
                if remaining_mem[dest] < m.model_size:
                    continue

                # Simulate move
                new_rem_worst = remaining_mem[worst_gpu] + m.model_size
                new_w_worst = weights[worst_gpu] - wm
                new_rem_dest = remaining_mem[dest] - m.model_size
                new_w_dest = weights[dest] + wm

                new_max = 0.0
                for j in range(gpu_num):
                    if j == worst_gpu:
                        v = kvpr(new_w_worst, new_rem_worst)
                    elif j == dest:
                        v = kvpr(new_w_dest, new_rem_dest)
                    else:
                        v = kvpr(weights[j], remaining_mem[j])
                    if v > new_max:
                        new_max = v

                if new_max + 1e-12 < current_max:
                    # Commit the move
                    placement[worst_gpu].remove(m)
                    placement[dest].append(m)
                    weights[worst_gpu] = new_w_worst
                    remaining_mem[worst_gpu] = new_rem_worst
                    weights[dest] = new_w_dest
                    remaining_mem[dest] = new_rem_dest
                    improved = True
                    return improved  # first improving move
        return improved

    def try_improve_by_swaps():
        # Attempt pairwise swaps between the bottleneck GPU and others.
        kvprs = current_kvprs(weights, remaining_mem)
        worst_gpu = max(range(gpu_num), key=lambda i: kvprs[i])
        current_max = kvprs[worst_gpu]
        improved = False

        if not placement[worst_gpu]:
            return False

        for m in placement[worst_gpu]:
            wm = weight_of(m)
            for other in range(gpu_num):
                if other == worst_gpu or not placement[other]:
                    continue
                for n in placement[other]:
                    wn = weight_of(n)

                    # Simulate swap worst_gpu:m <-> other:n
                    new_rem_worst = remaining_mem[worst_gpu] + m.model_size - n.model_size
                    new_rem_other = remaining_mem[other] + n.model_size - m.model_size

                    if new_rem_worst < 0 or new_rem_other < 0:
                        continue  # invalid swap (exceeds memory)

                    new_w_worst = weights[worst_gpu] - wm + wn
                    new_w_other = weights[other] - wn + wm

                    new_max = 0.0
                    for j in range(gpu_num):
                        if j == worst_gpu:
                            v = kvpr(new_w_worst, new_rem_worst)
                        elif j == other:
                            v = kvpr(new_w_other, new_rem_other)
                        else:
                            v = kvpr(weights[j], remaining_mem[j])
                        if v > new_max:
                            new_max = v

                    if new_max + 1e-12 < current_max:
                        # Commit swap
                        placement[worst_gpu].remove(m)
                        placement[other].append(m)
                        placement[other].remove(n)
                        placement[worst_gpu].append(n)

                        weights[worst_gpu] = new_w_worst
                        remaining_mem[worst_gpu] = new_rem_worst
                        weights[other] = new_w_other
                        remaining_mem[other] = new_rem_other
                        improved = True
                        return improved  # first improving swap
        return improved

    # Perform a limited number of improvement iterations to keep runtime low.
    # We attempt moves first, then swaps, until no improvement.
    max_iterations = 200
    for _ in range(max_iterations):
        if try_improve_by_moves():
            continue
        if try_improve_by_swaps():
            continue
        break  # no improvement found

    return placement

# EVOLVE-BLOCK-END


if __name__ == "__main__":
    # Test the algorithm

    from evaluator import generate_test_gpu_models
    from evaluator import calculate_kvcache_pressure
    from evaluator import safe_float
    import numpy as np

    test_cases = generate_test_gpu_models()
    all_kvpr = []
    for i, (gpu_num, gpu_models) in enumerate(test_cases):

        results = compute_model_placement(gpu_num, gpu_models)
        max_kvpr = calculate_kvcache_pressure(results)
        all_kvpr.append(safe_float(max_kvpr))

    avg_kvpr = np.mean(all_kvpr)
    if avg_kvpr != 0:
        avg_kvpr = 1.0 / avg_kvpr


    print(f"Max KVPR: {avg_kvpr:.3f}")