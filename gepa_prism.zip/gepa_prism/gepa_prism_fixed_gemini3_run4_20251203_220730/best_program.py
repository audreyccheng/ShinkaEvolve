GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.
    Strategy: Runs multiple greedy heuristics (weighted, sized, density) followed by 
    L2-norm guided local search to find the global optimum.
    """
    
    # Pre-process models into a standard dict format
    # This avoids repeated attribute access and calculations
    wrapped_models = []
    for m in models:
        weight = m.req_rate / m.slo
        wrapped_models.append({
            'model': m,
            'w': weight,
            's': m.model_size
        })

    # Helper: Calculate KVPR safely
    def get_kvpr(w, s):
        rem = GPU_MEM_SIZE - s
        if rem <= 1e-7: # Handle effectively full or over-full memory
            return float('inf')
        return w / rem

    # Core Solver Logic
    def solve_with_order(sorted_items):
        # State initialization
        gpu_items = [[] for _ in range(gpu_num)]
        gpu_w = [0.0] * gpu_num
        gpu_s = [0.0] * gpu_num
        
        # --- Phase 1: Greedy Placement with Look-Ahead ---
        for item in sorted_items:
            best_gpu = -1
            # Comparison tuple: (Global Max KVPR, Local KVPR, -Remaining Memory)
            best_score = None 
            
            # Cache current KVPRs for look-ahead
            current_kvprs = [get_kvpr(gpu_w[k], gpu_s[k]) for k in range(gpu_num)]
            
            for i in range(gpu_num):
                # 1. Capacity Check
                if gpu_s[i] + item['s'] > GPU_MEM_SIZE:
                    continue
                
                # 2. Simulate Placement
                new_w = gpu_w[i] + item['w']
                new_s = gpu_s[i] + item['s']
                new_local_kvpr = get_kvpr(new_w, new_s)
                
                # 3. Calculate Hypothetical Global Max
                # It is the max of (this gpu's new kvpr, max of all other gpus)
                max_others = 0.0
                for j in range(gpu_num):
                    if i == j: continue
                    if current_kvprs[j] > max_others:
                        max_others = current_kvprs[j]
                
                hypothetical_global_max = max(new_local_kvpr, max_others)
                
                # 4. Score Calculation
                # We minimize: Global Max -> Local KVPR -> Used Memory (Maximize Free Space)
                # Using -(Free Space) is equivalent to minimizing Used Memory? 
                # No, we want to MAXIMIZE free space to prevent bottlenecks.
                # So we minimize: (Global, Local, -FreeSpace) => (Global, Local, Used)
                score = (hypothetical_global_max, new_local_kvpr, new_s)
                
                if best_score is None or score < best_score:
                    best_score = score
                    best_gpu = i
            
            if best_gpu == -1:
                return None, float('inf') # Failed to fit model
            
            # Commit placement
            gpu_items[best_gpu].append(item)
            gpu_w[best_gpu] += item['w']
            gpu_s[best_gpu] += item['s']

        # --- Phase 2: Local Search with L2 Tie-Breaking ---
        # We try to reduce Max KVPR. If Max KVPR is unchanged, we try to reduce
        # the Sum of Squared KVPRs (variance), which helps unblock future moves.
        
        max_iter = 500
        for _ in range(max_iter):
            current_kvprs = [get_kvpr(gpu_w[i], gpu_s[i]) for i in range(gpu_num)]
            max_kvpr = max(current_kvprs)
            
            if max_kvpr == 0: break
            
            # Current "energy" of the system
            current_l2 = sum(k*k for k in current_kvprs)
            
            # Identify bottlenecks (GPUs close to the max)
            bottlenecks = [i for i, v in enumerate(current_kvprs) if v >= max_kvpr - 1e-9]
            src_gpu = bottlenecks[0] # Pick the first bottleneck to alleviate
            
            improved = False
            
            # Helper to validate a move/swap
            def check_improvement(test_kvprs):
                new_max = max(test_kvprs)
                # Strict improvement in Max KVPR
                if new_max < max_kvpr - 1e-9:
                    return True
                # Tie-breaking: Improvement in L2 norm (smoother distribution)
                if abs(new_max - max_kvpr) < 1e-9:
                    new_l2 = sum(k*k for k in test_kvprs)
                    if new_l2 < current_l2 - 1e-9:
                        return True
                return False

            # Strategy A: Move model from bottleneck to another GPU
            for idx, item in enumerate(gpu_items[src_gpu]):
                for dst_gpu in range(gpu_num):
                    if dst_gpu == src_gpu: continue
                    if gpu_s[dst_gpu] + item['s'] > GPU_MEM_SIZE: continue
                    
                    # Simulate Move
                    src_k = get_kvpr(gpu_w[src_gpu] - item['w'], gpu_s[src_gpu] - item['s'])
                    dst_k = get_kvpr(gpu_w[dst_gpu] + item['w'], gpu_s[dst_gpu] + item['s'])
                    
                    # Construct temp KVPR list for check
                    test_kvprs = list(current_kvprs)
                    test_kvprs[src_gpu] = src_k
                    test_kvprs[dst_gpu] = dst_k
                    
                    if check_improvement(test_kvprs):
                        # Apply Move
                        obj = gpu_items[src_gpu].pop(idx)
                        gpu_items[dst_gpu].append(obj)
                        gpu_w[src_gpu] -= item['w']; gpu_s[src_gpu] -= item['s']
                        gpu_w[dst_gpu] += item['w']; gpu_s[dst_gpu] += item['s']
                        improved = True
                        break
                if improved: break
            
            if improved: continue # Restart loop if state changed
            
            # Strategy B: Swap models
            for idx_a, item_a in enumerate(gpu_items[src_gpu]):
                for dst_gpu in range(gpu_num):
                    if dst_gpu == src_gpu: continue
                    
                    for idx_b, item_b in enumerate(gpu_items[dst_gpu]):
                        # Simulate Capacity
                        new_src_s = gpu_s[src_gpu] - item_a['s'] + item_b['s']
                        new_dst_s = gpu_s[dst_gpu] - item_b['s'] + item_a['s']
                        
                        if new_src_s > GPU_MEM_SIZE or new_dst_s > GPU_MEM_SIZE:
                            continue
                            
                        # Simulate Weights & KVPR
                        new_src_w = gpu_w[src_gpu] - item_a['w'] + item_b['w']
                        new_dst_w = gpu_w[dst_gpu] - item_b['w'] + item_a['w']
                        
                        src_k = get_kvpr(new_src_w, new_src_s)
                        dst_k = get_kvpr(new_dst_w, new_dst_s)
                        
                        test_kvprs = list(current_kvprs)
                        test_kvprs[src_gpu] = src_k
                        test_kvprs[dst_gpu] = dst_k
                        
                        if check_improvement(test_kvprs):
                            # Apply Swap
                            gpu_items[src_gpu][idx_a] = item_b
                            gpu_items[dst_gpu][idx_b] = item_a
                            gpu_w[src_gpu] = new_src_w; gpu_s[src_gpu] = new_src_s
                            gpu_w[dst_gpu] = new_dst_w; gpu_s[dst_gpu] = new_dst_s
                            improved = True
                            break
                    if improved: break
                if improved: break
            
            if not improved: break # Local optimum reached

        final_max_kvpr = max(get_kvpr(gpu_w[i], gpu_s[i]) for i in range(gpu_num))
        return gpu_items, final_max_kvpr

    # --- Execution: Multi-Start Heuristic ---
    
    # 1. Sort by Weight (Pressure) Descending
    s1 = sorted(wrapped_models, key=lambda x: (x['w'], x['s']), reverse=True)
    # 2. Sort by Size Descending (Fit Large)
    s2 = sorted(wrapped_models, key=lambda x: (x['s'], x['w']), reverse=True)
    # 3. Sort by Density (Pressure per GB) Descending
    s3 = sorted(wrapped_models, key=lambda x: (x['w']/(x['s'] + 1e-5), x['w']), reverse=True)

    best_result = None
    best_kvpr = float('inf')

    # Try all strategies and pick the best valid result
    for sorted_models in [s1, s2, s3]:
        res_items, res_kvpr = solve_with_order(sorted_models)
        if res_items is not None:
            if res_kvpr < best_kvpr:
                best_kvpr = res_kvpr
                best_result = res_items

    # If all failed (shouldn't happen for valid inputs), raise error
    if best_result is None:
        raise ValueError("Unable to place models on GPUs due to memory constraints.")

    # Format Output
    placement = {i: [x['model'] for x in best_result[i]] for i in range(gpu_num)}
    return placement

# EVOLVE-BLOCK-END