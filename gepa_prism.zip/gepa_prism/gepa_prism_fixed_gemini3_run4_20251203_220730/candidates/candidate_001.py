GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.
    KVPR = sum(req_rate/slo) / (GPU_MEM_SIZE - sum(model_size))
    """
    
    # Pre-process models to extract relevant metrics for easier handling
    model_data = []
    for m in models:
        weight = m.req_rate / m.slo
        model_data.append({
            'model': m,
            'weight': weight,
            'size': m.model_size
        })
    
    # Sorting Strategy:
    # 1. Primary: Weight (req_rate/slo) Descending. High-pressure models are hardest to balance.
    # 2. Secondary: Size Descending. Large models are hardest to fit.
    model_data.sort(key=lambda x: (x['weight'], x['size']), reverse=True)

    # Initialize GPU states
    assigned_data = [[] for _ in range(gpu_num)]
    gpu_weights = [0.0] * gpu_num
    gpu_mem_used = [0.0] * gpu_num
    
    # Helper to calculate KVPR safely
    def get_kvpr(w, mem_used):
        remaining = GPU_MEM_SIZE - mem_used
        if remaining <= 1e-6: # Treat effectively 0 or negative memory as infinite pressure
            return float('inf')
        return w / remaining

    # --- Phase 1: Greedy Placement with Global Look-Ahead ---
    for item in model_data:
        m_weight = item['weight']
        m_size = item['size']
        
        best_gpu = -1
        best_global_max_kvpr = float('inf')
        # Tie-breakers
        best_local_kvpr = float('inf') 
        best_rem_mem = -1

        # Calculate current KVPRs for all GPUs to use in comparison
        current_kvprs = [get_kvpr(gpu_weights[i], gpu_mem_used[i]) for i in range(gpu_num)]

        for gpu_id in range(gpu_num):
            # 1. Capacity Constraint Check
            if gpu_mem_used[gpu_id] + m_size > GPU_MEM_SIZE:
                continue
            
            # 2. Simulate Placement on this GPU
            new_local_weight = gpu_weights[gpu_id] + m_weight
            new_local_mem = gpu_mem_used[gpu_id] + m_size
            new_local_kvpr = get_kvpr(new_local_weight, new_local_mem)
            
            # 3. Calculate Hypothetical Global Max KVPR
            # The new global max is either the new local KVPR for this GPU,
            # or the existing max KVPR among all OTHER GPUs.
            max_others = 0.0
            for other_id in range(gpu_num):
                if other_id != gpu_id:
                    if current_kvprs[other_id] > max_others:
                        max_others = current_kvprs[other_id]
            
            hypothetical_global_max = max(new_local_kvpr, max_others)
            
            # 4. Selection Logic
            # Priority A: Minimize the Future Global Max KVPR
            if hypothetical_global_max < best_global_max_kvpr:
                best_global_max_kvpr = hypothetical_global_max
                best_gpu = gpu_id
                best_local_kvpr = new_local_kvpr
                best_rem_mem = GPU_MEM_SIZE - new_local_mem
            
            # Priority B: Tie-breaking
            elif abs(hypothetical_global_max - best_global_max_kvpr) < 1e-9:
                # Sub-priority 1: Minimize Local KVPR (keep the target GPU cooler)
                if new_local_kvpr < best_local_kvpr - 1e-9:
                    best_gpu = gpu_id
                    best_local_kvpr = new_local_kvpr
                    best_rem_mem = GPU_MEM_SIZE - new_local_mem
                elif abs(new_local_kvpr - best_local_kvpr) <= 1e-9:
                    # Sub-priority 2: Maximize remaining memory (leave space for future big models)
                    current_rem = GPU_MEM_SIZE - new_local_mem
                    if current_rem > best_rem_mem:
                        best_gpu = gpu_id
                        best_rem_mem = current_rem

        if best_gpu == -1:
            raise ValueError(f"Unable to place model {item['model'].model_name} (Size: {m_size}) on any GPU.")

        # Commit placement
        assigned_data[best_gpu].append(item)
        gpu_weights[best_gpu] += m_weight
        gpu_mem_used[best_gpu] += m_size

    # --- Phase 2: Local Search (Iterative Improvement) ---
    # Attempt to reduce the maximum KVPR by Moving or Swapping models from the bottleneck GPU.
    
    max_iterations = 150 # Iteration limit to prevent infinite loops
    
    for _ in range(max_iterations):
        # 1. Identify Current Bottleneck
        current_kvprs = [get_kvpr(gpu_weights[i], gpu_mem_used[i]) for i in range(gpu_num)]
        max_kvpr = max(current_kvprs)
        
        # If pressure is 0, we can't improve
        if max_kvpr == 0: break 
        
        # Find the GPU causing the max KVPR (could be multiple, pick first)
        bottlenecks = [i for i, v in enumerate(current_kvprs) if abs(v - max_kvpr) < 1e-7]
        src_gpu = bottlenecks[0] 
        
        improved = False
        
        # Strategy A: Move a model from bottleneck GPU to another GPU
        for idx, item in enumerate(assigned_data[src_gpu]):
            m_weight = item['weight']
            m_size = item['size']
            
            for dst_gpu in range(gpu_num):
                if dst_gpu == src_gpu: continue
                
                # Check Fit
                if gpu_mem_used[dst_gpu] + m_size > GPU_MEM_SIZE:
                    continue
                
                # Simulate Move
                src_kvpr_new = get_kvpr(gpu_weights[src_gpu] - m_weight, gpu_mem_used[src_gpu] - m_size)
                dst_kvpr_new = get_kvpr(gpu_weights[dst_gpu] + m_weight, gpu_mem_used[dst_gpu] + m_size)
                
                # Calculate new global max to verify improvement
                # We need to construct the full list of KVPRs to be sure
                temp_kvprs = list(current_kvprs)
                temp_kvprs[src_gpu] = src_kvpr_new
                temp_kvprs[dst_gpu] = dst_kvpr_new
                new_global_max = max(temp_kvprs)
                
                # Strict improvement check
                if new_global_max < max_kvpr - 1e-9:
                    # Apply Move
                    item_to_move = assigned_data[src_gpu].pop(idx)
                    assigned_data[dst_gpu].append(item_to_move)
                    
                    gpu_weights[src_gpu] -= m_weight
                    gpu_mem_used[src_gpu] -= m_size
                    gpu_weights[dst_gpu] += m_weight
                    gpu_mem_used[dst_gpu] += m_size
                    
                    improved = True
                    break
            if improved: break
        
        if improved: continue # Restart loop to re-evaluate bottlenecks
        
        # Strategy B: Swap a model on bottleneck with a model on another GPU
        # (Only attempted if simple moves fail)
        for idx_a, item_a in enumerate(assigned_data[src_gpu]):
            for dst_gpu in range(gpu_num):
                if dst_gpu == src_gpu: continue
                
                # Optimization: Don't swap with another bottleneck unless it fixes things
                if current_kvprs[dst_gpu] > max_kvpr - 1e-6: continue

                for idx_b, item_b in enumerate(assigned_data[dst_gpu]):
                    # Simulate Swap Memory
                    new_src_mem = gpu_mem_used[src_gpu] - item_a['size'] + item_b['size']
                    new_dst_mem = gpu_mem_used[dst_gpu] - item_b['size'] + item_a['size']
                    
                    if new_src_mem > GPU_MEM_SIZE or new_dst_mem > GPU_MEM_SIZE:
                        continue
                    
                    # Simulate Swap Weights
                    new_src_w = gpu_weights[src_gpu] - item_a['weight'] + item_b['weight']
                    new_dst_w = gpu_weights[dst_gpu] - item_b['weight'] + item_a['weight']
                    
                    new_src_kvpr = get_kvpr(new_src_w, new_src_mem)
                    new_dst_kvpr = get_kvpr(new_dst_w, new_dst_mem)
                    
                    # Verify Improvement
                    temp_kvprs = list(current_kvprs)
                    temp_kvprs[src_gpu] = new_src_kvpr
                    temp_kvprs[dst_gpu] = new_dst_kvpr
                    new_global_max = max(temp_kvprs)
                    
                    if new_global_max < max_kvpr - 1e-9:
                        # Apply Swap
                        assigned_data[src_gpu][idx_a] = item_b
                        assigned_data[dst_gpu][idx_b] = item_a
                        
                        gpu_weights[src_gpu] = new_src_w
                        gpu_mem_used[src_gpu] = new_src_mem
                        gpu_weights[dst_gpu] = new_dst_w
                        gpu_mem_used[dst_gpu] = new_dst_mem
                        
                        improved = True
                        break
                if improved: break
            if improved: break
        
        if not improved:
            break # Local optimum reached

    # Format Output
    placement = {i: [x['model'] for x in assigned_data[i]] for i in range(gpu_num)}
    return placement

# EVOLVE-BLOCK-END