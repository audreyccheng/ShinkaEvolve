GPU_MEM_SIZE = 80  # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.

    KVPR for a GPU = sum(model.req_rate / model.slo) / (GPU_MEM_SIZE - sum(model.model_size))
    If remaining memory <= 0, KVPR is considered infinity.

    Args:
        gpu_num: Number of GPUs
        models: List of models to place

    Returns:
        A dictionary mapping GPU IDs to lists of Model objects.
    """

    # ------------------------
    # Helpers
    # ------------------------
    def weight_of(m):
        # pressure weight: larger is heavier. Guard against slo=0
        slo = getattr(m, "slo", 0)
        if slo in (0, None):
            return float('inf')
        return (m.req_rate / slo)

    def kvpr(remain_mem, weight_sum):
        if remain_mem <= 0:
            return float('inf')
        return weight_sum / remain_mem

    def max_kvpr(weight_sums, remain_mems):
        mx = 0.0
        for w, r in zip(weight_sums, remain_mems):
            v = kvpr(r, w)
            if v > mx:
                mx = v
        return mx

    def compute_state_kvprs(remain_mems, weight_sums):
        return [kvpr(remain_mems[i], weight_sums[i]) for i in range(gpu_num)]

    eps = 1e-12

    # Precompute for global estimations
    total_w = 0.0
    any_inf_w = False
    for m in models:
        w = weight_of(m)
        if w == float('inf'):
            any_inf_w = True
        else:
            total_w += w
    total_size = sum(getattr(m, "model_size", 0) for m in models)
    total_rem_after_all = gpu_num * GPU_MEM_SIZE - total_size
    if total_rem_after_all <= 0:
        # Impossible to place all models within memory constraint
        raise ValueError("Total model sizes exceed total GPU memory.")
    # Estimated optimal equalized KVPR if everything could be fractionally balanced
    if any_inf_w:
        t_est = 1e12  # very large to effectively ignore w/t_est in waterfill score
    else:
        t_est = max(total_w / max(total_rem_after_all, 1e-9), 1e-12)

    # ------------------------
    # Greedy placement with global look-ahead + waterfill-aware tiebreak
    # ------------------------
    def greedy_place(ordered_models):
        placement = {gpu_id: [] for gpu_id in range(gpu_num)}
        remaining_mem = [GPU_MEM_SIZE for _ in range(gpu_num)]
        weights = [0.0 for _ in range(gpu_num)]  # sum of req_rate/slo per GPU

        for model in ordered_models:
            w = weight_of(model)
            s = model.model_size

            best_gpu = None
            best_future_max = float('inf')
            best_tie = None  # tuple for tie-breaking

            for g in range(gpu_num):
                if s <= remaining_mem[g]:
                    # simulate place on g
                    rem_after = remaining_mem[g] - s
                    w_after = weights[g] + w

                    # compute future max KVPR across all GPUs after this placement
                    future_max = 0.0
                    for i in range(gpu_num):
                        if i == g:
                            v = kvpr(rem_after, w_after)
                        else:
                            v = kvpr(remaining_mem[i], weights[i])
                        if v > future_max:
                            future_max = v

                    # tie-breaking:
                    # 1) minimize future_max (handled by best_future_max)
                    # 2) prefer higher waterfill margin A_after = rem_after - w_after/t_est
                    # 3) prefer larger remaining memory after placement (rem_after)
                    # 4) prefer lower local KVPR on the chosen GPU after placement
                    # Note: larger tie tuple is preferred
                    local_kvpr_after = kvpr(rem_after, w_after)
                    A_after = rem_after - (w_after / t_est)
                    tie = (A_after, rem_after, -local_kvpr_after)

                    if (future_max + eps) < best_future_max:
                        best_future_max = future_max
                        best_gpu = g
                        best_tie = tie
                    elif abs(future_max - best_future_max) <= eps:
                        if best_tie is None or tie > best_tie:
                            best_gpu = g
                            best_tie = tie

            if best_gpu is None:
                # Cannot fit this model anywhere
                raise ValueError(
                    f"Unable to place model '{getattr(model, 'model_name', '')}' of size {s} GB on any GPU. "
                    f"Remaining per-GPU memory: {remaining_mem}"
                )

            placement[best_gpu].append(model)
            remaining_mem[best_gpu] -= s
            weights[best_gpu] += w

        return placement, remaining_mem, weights

    # ------------------------
    # Local search improvements
    # ------------------------
    def try_best_single_move_allpairs(placement, remaining_mem, weights):
        """Try the best single move across all src->dst pairs that reduces max KVPR."""
        current_max = max_kvpr(weights, remaining_mem)
        best_new_max = current_max - eps
        best_action = None  # ('move', src, dst, model)

        for src in range(gpu_num):
            if not placement[src]:
                continue
            for model in placement[src]:
                s = model.model_size
                w = weight_of(model)
                for dst in range(gpu_num):
                    if dst == src:
                        continue
                    if s <= remaining_mem[dst]:
                        # Simulate move
                        rems = list(remaining_mem)
                        wts = list(weights)
                        # remove from src
                        rems[src] += s
                        wts[src] -= w
                        # add to dst
                        rems[dst] -= s
                        wts[dst] += w
                        new_max = max_kvpr(wts, rems)
                        if new_max + eps < best_new_max:
                            best_new_max = new_max
                            best_action = ('move', src, dst, model)

        if best_action is not None:
            _, src, dst, model = best_action
            placement[src].remove(model)
            placement[dst].append(model)
            s = model.model_size
            w = weight_of(model)
            remaining_mem[src] += s
            weights[src] -= w
            remaining_mem[dst] -= s
            weights[dst] += w
            return True
        return False

    def try_best_swap_allpairs(placement, remaining_mem, weights):
        """Try the best pairwise swap across all GPU pairs that reduces max KVPR."""
        current_max = max_kvpr(weights, remaining_mem)
        best_new_max = current_max - eps
        best_action = None  # ('swap', a, b, model_a, model_b)

        for a in range(gpu_num):
            if not placement[a]:
                continue
            for b in range(a + 1, gpu_num):
                if not placement[b]:
                    continue
                for m_a in placement[a]:
                    s_a = m_a.model_size
                    w_a = weight_of(m_a)
                    for m_b in placement[b]:
                        s_b = m_b.model_size
                        w_b = weight_of(m_b)

                        # Feasibility after swap
                        if (remaining_mem[a] + s_a - s_b) < 0:
                            continue
                        if (remaining_mem[b] + s_b - s_a) < 0:
                            continue

                        # Simulate swap
                        rems = list(remaining_mem)
                        wts = list(weights)

                        rems[a] = remaining_mem[a] + s_a - s_b
                        rems[b] = remaining_mem[b] + s_b - s_a
                        wts[a] = weights[a] - w_a + w_b
                        wts[b] = weights[b] - w_b + w_a

                        new_max = max_kvpr(wts, rems)
                        if new_max + eps < best_new_max:
                            best_new_max = new_max
                            best_action = ('swap', a, b, m_a, m_b)

        if best_action is not None:
            _, a, b, m_a, m_b = best_action
            placement[a].remove(m_a)
            placement[b].append(m_a)
            placement[b].remove(m_b)
            placement[a].append(m_b)

            s_a = m_a.model_size
            w_a = weight_of(m_a)
            s_b = m_b.model_size
            w_b = weight_of(m_b)

            remaining_mem[a] = remaining_mem[a] + s_a - s_b
            weights[a] = weights[a] - w_a + w_b
            remaining_mem[b] = remaining_mem[b] + s_b - s_a
            weights[b] = weights[b] - w_b + w_a
            return True
        return False

    def try_best_twohop_chain(placement, remaining_mem, weights):
        """
        Try a two-hop chain move to reduce max KVPR:
        Move model m: src -> dst (may not fit initially),
        then free space on dst by moving one model b1: dst -> c.
        """
        current_max = max_kvpr(weights, remaining_mem)
        best_new_max = current_max - eps
        best_action = None  # ('chain', src, dst, c, model_m, model_b1)

        # Focus on highest-KVPR GPUs as sources
        kvprs = compute_state_kvprs(remaining_mem, weights)
        max_val = max(kvprs)
        candidate_srcs = [i for i, v in enumerate(kvprs) if abs(v - max_val) <= 1e-12]

        for src in candidate_srcs:
            if not placement[src]:
                continue
            for m in placement[src]:
                s_m = m.model_size
                w_m = weight_of(m)
                for dst in range(gpu_num):
                    if dst == src:
                        continue
                    # If it fits, single-move already handles; skip here to search only blocked moves
                    if s_m <= remaining_mem[dst]:
                        continue
                    need = s_m - remaining_mem[dst]
                    if not placement[dst]:
                        continue
                    for b1 in placement[dst]:
                        s_b1 = b1.model_size
                        w_b1 = weight_of(b1)
                        # Try moving b1 from dst to c
                        for c in range(gpu_num):
                            if c == dst:
                                continue
                            if s_b1 <= remaining_mem[c]:
                                # After moving b1 out, does m fit into dst?
                                if remaining_mem[dst] + s_b1 < s_m:
                                    continue
                                # Simulate chain: dst->c (b1), then src->dst (m)
                                rems = list(remaining_mem)
                                wts = list(weights)
                                # dst -> c (b1)
                                rems[dst] += s_b1
                                wts[dst] -= w_b1
                                rems[c] -= s_b1
                                if rems[c] < 0:  # safety
                                    continue
                                wts[c] += w_b1
                                # src -> dst (m)
                                rems[src] += s_m
                                wts[src] -= w_m
                                rems[dst] -= s_m
                                if rems[dst] < 0:
                                    continue
                                wts[dst] += w_m

                                new_max = max_kvpr(wts, rems)
                                if new_max + eps < best_new_max:
                                    best_new_max = new_max
                                    best_action = ('chain', src, dst, c, m, b1)

        if best_action is not None:
            _, src, dst, c, m, b1 = best_action
            # Apply: move b1 dst->c, then m src->dst
            placement[dst].remove(b1)
            placement[c].append(b1)
            s_b1 = b1.model_size
            w_b1 = weight_of(b1)
            remaining_mem[dst] += s_b1
            weights[dst] -= w_b1
            remaining_mem[c] -= s_b1
            weights[c] += w_b1

            placement[src].remove(m)
            placement[dst].append(m)
            s_m = m.model_size
            w_m = weight_of(m)
            remaining_mem[src] += s_m
            weights[src] -= w_m
            remaining_mem[dst] -= s_m
            weights[dst] += w_m
            return True

        return False

    def local_search(placement, remaining_mem, weights, max_iters=80):
        for _ in range(max_iters):
            improved = False
            if try_best_single_move_allpairs(placement, remaining_mem, weights):
                improved = True
                continue
            if try_best_swap_allpairs(placement, remaining_mem, weights):
                improved = True
                continue
            if try_best_twohop_chain(placement, remaining_mem, weights):
                improved = True
                continue
            if not improved:
                break
        return placement, remaining_mem, weights

    # ------------------------
    # Multi-start: try several model orderings, pick the best result
    # ------------------------
    # Precompute basic magnitudes to avoid recomputing in sorting keys
    pre_w = {id(m): weight_of(m) for m in models}
    pre_s = {id(m): m.model_size for m in models}

    # Harm index: approximate impact if placed on an empty GPU.
    def harm_index(m):
        s = pre_s[id(m)]
        remain_if_only = max(GPU_MEM_SIZE - s, 1e-9)
        return pre_w[id(m)] / remain_if_only

    # Waterfill "cost": size plus weight discounted by estimated t_est
    def waterfill_cost(m):
        return pre_s[id(m)] + pre_w[id(m)] / t_est

    # Define several orderings to try
    orderings = [
        ("by_harm_then_size", lambda m: (harm_index(m), pre_s[id(m)]), True),
        ("by_weight_then_size", lambda m: (pre_w[id(m)], pre_s[id(m)]), True),
        ("by_weight_density", lambda m: ((pre_w[id(m)] / max(pre_s[id(m)], 1e-9)), pre_s[id(m)]), True),
        ("by_size_then_weight", lambda m: (pre_s[id(m)], pre_w[id(m)]), True),
        ("by_waterfill_cost", lambda m: waterfill_cost(m), True),
        ("by_size_only", lambda m: pre_s[id(m)], True),
    ]

    best_overall = None  # (max_kvpr_value, placement, remaining_mem, weights)

    for _, key_fn, reverse in orderings:
        ordered = sorted(models, key=key_fn, reverse=reverse)
        try:
            placement, remaining_mem, weights = greedy_place(ordered)
        except ValueError:
            # If a particular ordering cannot place all models, skip it
            continue

        # Local search to refine
        placement, remaining_mem, weights = local_search(placement, remaining_mem, weights)

        # Evaluate
        cur_max = max_kvpr(weights, remaining_mem)
        if (best_overall is None) or (cur_max < best_overall[0] - eps):
            best_overall = (cur_max, placement, remaining_mem, weights)

    if best_overall is None:
        # As a very last resort (shouldn't happen if feasible), try naive order
        ordered = list(models)
        placement, remaining_mem, weights = greedy_place(ordered)
        placement, remaining_mem, weights = local_search(placement, remaining_mem, weights)
        return placement

    return best_overall[1]

# EVOLVE-BLOCK-END


if __name__ == "__main__":
    # Test the algorithm

    from evaluator import generate_test_gpu_models
    from evaluator import calculate_kvcache_pressure
    from evaluator import safe_float
    import numpy as np

    test_cases = generate_test_gpu_models()
    all_kvpr = []
    for i, (gpu_num, gpu_models) in enumerate(test_cases):

        results = compute_model_placement(gpu_num, gpu_models)
        max_kvpr = calculate_kvcache_pressure(results)
        all_kvpr.append(safe_float(max_kvpr))

    avg_kvpr = np.mean(all_kvpr)
    if avg_kvpr != 0:
        avg_kvpr = 1.0 / avg_kvpr

    print(f"Max KVPR: {avg_kvpr:.3f}")