GPU_MEM_SIZE = 80  # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.

    KVPR for a GPU = sum(model.req_rate / model.slo) / (GPU_MEM_SIZE - sum(model.model_size))
    If remaining memory <= 0, KVPR is considered infinity.

    Args:
        gpu_num: Number of GPUs
        models: List of models to place

    Returns:
        A dictionary mapping GPU IDs to lists of Model objects.
    """

    # ------------------------
    # Helpers
    # ------------------------
    def weight_of(m):
        # pressure weight: larger is heavier. Guard against slo=0
        return (m.req_rate / m.slo) if getattr(m, "slo", 0) not in (0, None) else float('inf')

    def kvpr(remain_mem, weight_sum):
        if remain_mem <= 0:
            return float('inf')
        return weight_sum / remain_mem

    def max_kvpr(weight_sums, remain_mems):
        mx = 0.0
        for w, r in zip(weight_sums, remain_mems):
            v = kvpr(r, w)
            if v > mx:
                mx = v
        return mx

    def compute_state_kvprs(remain_mems, weight_sums):
        return [kvpr(remain_mems[i], weight_sums[i]) for i in range(gpu_num)]

    eps = 1e-12

    # ------------------------
    # Greedy placement with global look-ahead
    # ------------------------
    def greedy_place(ordered_models):
        placement = {gpu_id: [] for gpu_id in range(gpu_num)}
        remaining_mem = [GPU_MEM_SIZE for _ in range(gpu_num)]
        weights = [0.0 for _ in range(gpu_num)]  # sum of req_rate/slo per GPU

        for model in ordered_models:
            w = weight_of(model)
            s = model.model_size

            best_gpu = None
            best_future_max = float('inf')
            best_tie = None  # tuple for tie-breaking

            for g in range(gpu_num):
                if s <= remaining_mem[g]:
                    # simulate place on g
                    rem_after = remaining_mem[g] - s
                    w_after = weights[g] + w

                    # compute future max KVPR across all GPUs after this placement
                    future_max = 0.0
                    for i in range(gpu_num):
                        if i == g:
                            v = kvpr(rem_after, w_after)
                        else:
                            v = kvpr(remaining_mem[i], weights[i])
                        if v > future_max:
                            future_max = v

                    # tie-breaking:
                    # 1) minimize future_max
                    # 2) prefer larger remaining memory after placement (more headroom)
                    # 3) prefer lower local KVPR on the chosen GPU after placement
                    local_kvpr_after = kvpr(rem_after, w_after)
                    tie = (rem_after, -local_kvpr_after)

                    if (future_max + eps) < best_future_max:
                        best_future_max = future_max
                        best_gpu = g
                        best_tie = tie
                    elif abs(future_max - best_future_max) <= eps:
                        if best_tie is None or tie > best_tie:
                            best_gpu = g
                            best_tie = tie

            if best_gpu is None:
                # Cannot fit this model anywhere
                raise ValueError(
                    f"Unable to place model '{getattr(model, 'model_name', '')}' of size {s} GB on any GPU. "
                    f"Remaining per-GPU memory: {remaining_mem}"
                )

            placement[best_gpu].append(model)
            remaining_mem[best_gpu] -= s
            weights[best_gpu] += w

        return placement, remaining_mem, weights

    # ------------------------
    # Local search improvements
    # ------------------------
    def try_best_single_move_allpairs(placement, remaining_mem, weights):
        """Try the best single move across all src->dst pairs that reduces max KVPR."""
        current_max = max_kvpr(weights, remaining_mem)
        best_new_max = current_max - eps
        best_action = None  # ('move', src, dst, model)

        for src in range(gpu_num):
            if not placement[src]:
                continue
            for model in placement[src]:
                s = model.model_size
                w = weight_of(model)
                for dst in range(gpu_num):
                    if dst == src:
                        continue
                    if s <= remaining_mem[dst]:
                        # Simulate move
                        rems = list(remaining_mem)
                        wts = list(weights)
                        # remove from src
                        rems[src] += s
                        wts[src] -= w
                        # add to dst
                        rems[dst] -= s
                        wts[dst] += w
                        new_max = max_kvpr(wts, rems)
                        if new_max + eps < best_new_max:
                            best_new_max = new_max
                            best_action = ('move', src, dst, model)

        if best_action is not None:
            _, src, dst, model = best_action
            placement[src].remove(model)
            placement[dst].append(model)
            s = model.model_size
            w = weight_of(model)
            remaining_mem[src] += s
            weights[src] -= w
            remaining_mem[dst] -= s
            weights[dst] += w
            return True
        return False

    def try_best_swap_allpairs(placement, remaining_mem, weights):
        """Try the best pairwise swap across all GPU pairs that reduces max KVPR."""
        current_max = max_kvpr(weights, remaining_mem)
        best_new_max = current_max - eps
        best_action = None  # ('swap', a, b, model_a, model_b)

        for a in range(gpu_num):
            if not placement[a]:
                continue
            for b in range(a + 1, gpu_num):
                if not placement[b]:
                    continue
                for m_a in placement[a]:
                    s_a = m_a.model_size
                    w_a = weight_of(m_a)
                    for m_b in placement[b]:
                        s_b = m_b.model_size
                        w_b = weight_of(m_b)

                        # Feasibility after swap
                        if (remaining_mem[a] + s_a - s_b) < 0:
                            continue
                        if (remaining_mem[b] + s_b - s_a) < 0:
                            continue

                        # Simulate swap
                        rems = list(remaining_mem)
                        wts = list(weights)

                        rems[a] = remaining_mem[a] + s_a - s_b
                        rems[b] = remaining_mem[b] + s_b - s_a
                        wts[a] = weights[a] - w_a + w_b
                        wts[b] = weights[b] - w_b + w_a

                        new_max = max_kvpr(wts, rems)
                        if new_max + eps < best_new_max:
                            best_new_max = new_max
                            best_action = ('swap', a, b, m_a, m_b)

        if best_action is not None:
            _, a, b, m_a, m_b = best_action
            placement[a].remove(m_a)
            placement[b].append(m_a)
            placement[b].remove(m_b)
            placement[a].append(m_b)

            s_a = m_a.model_size
            w_a = weight_of(m_a)
            s_b = m_b.model_size
            w_b = weight_of(m_b)

            remaining_mem[a] = remaining_mem[a] + s_a - s_b
            weights[a] = weights[a] - w_a + w_b
            remaining_mem[b] = remaining_mem[b] + s_b - s_a
            weights[b] = weights[b] - w_b + w_a
            return True
        return False

    def local_search(placement, remaining_mem, weights, max_iters=80):
        for _ in range(max_iters):
            improved = False
            if try_best_single_move_allpairs(placement, remaining_mem, weights):
                improved = True
                continue
            if try_best_swap_allpairs(placement, remaining_mem, weights):
                improved = True
                continue
            if not improved:
                break
        return placement, remaining_mem, weights

    # ------------------------
    # Multi-start: try several model orderings, pick the best result
    # ------------------------
    # Precompute basic magnitudes to avoid recomputing in sorting keys
    pre_w = {id(m): weight_of(m) for m in models}
    pre_s = {id(m): m.model_size for m in models}

    # Harm index: approximate impact if placed on an empty GPU.
    def harm_index(m):
        s = pre_s[id(m)]
        remain_if_only = max(GPU_MEM_SIZE - s, 1e-9)
        return pre_w[id(m)] / remain_if_only

    # Define several orderings to try
    orderings = [
        ("by_harm_then_size", lambda m: (harm_index(m), pre_s[id(m)]), True),
        ("by_weight_then_size", lambda m: (pre_w[id(m)], pre_s[id(m)]), True),
        ("by_weight_density", lambda m: ((pre_w[id(m)] / max(pre_s[id(m)], 1e-9)), pre_s[id(m)]), True),
        ("by_size_then_weight", lambda m: (pre_s[id(m)], pre_w[id(m)]), True),
    ]

    best_overall = None  # (max_kvpr_value, placement, remaining_mem, weights)

    for _, key_fn, reverse in orderings:
        ordered = sorted(models, key=key_fn, reverse=reverse)
        try:
            placement, remaining_mem, weights = greedy_place(ordered)
        except ValueError:
            # If a particular ordering cannot place all models, skip it
            continue

        # Local search to refine
        placement, remaining_mem, weights = local_search(placement, remaining_mem, weights)

        # Evaluate
        cur_max = max_kvpr(weights, remaining_mem)
        if (best_overall is None) or (cur_max < best_overall[0] - eps):
            best_overall = (cur_max, placement, remaining_mem, weights)

    if best_overall is None:
        # As a very last resort (shouldn't happen if feasible), try naive order
        ordered = list(models)
        placement, remaining_mem, weights = greedy_place(ordered)
        placement, remaining_mem, weights = local_search(placement, remaining_mem, weights)
        return placement

    return best_overall[1]

# EVOLVE-BLOCK-END


if __name__ == "__main__":
    # Test the algorithm

    from evaluator import generate_test_gpu_models
    from evaluator import calculate_kvcache_pressure
    from evaluator import safe_float
    import numpy as np

    test_cases = generate_test_gpu_models()
    all_kvpr = []
    for i, (gpu_num, gpu_models) in enumerate(test_cases):

        results = compute_model_placement(gpu_num, gpu_models)
        max_kvpr = calculate_kvcache_pressure(results)
        all_kvpr.append(safe_float(max_kvpr))

    avg_kvpr = np.mean(all_kvpr)
    if avg_kvpr != 0:
        avg_kvpr = 1.0 / avg_kvpr

    print(f"Max KVPR: {avg_kvpr:.3f}")