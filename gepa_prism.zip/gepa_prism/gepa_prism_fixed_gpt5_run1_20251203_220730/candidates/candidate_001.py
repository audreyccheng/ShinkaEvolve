GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.

    Args:
        gpu_num: Number of GPUs
        models: List of models to place

    Returns:
        A placement of models to GPUs
    """
    # Helper functions
    def weight_of(m):
        return (m.req_rate / m.slo) if m.slo != 0 else float('inf')

    def kvpr(remain, weight):
        # KVPR = sum(req/slo) / remaining_memory; if remaining_memory <= 0 => inf
        if remain <= 0:
            return float('inf')
        return weight / remain

    def max_kvpr(weights, rems):
        mx = 0.0
        for w, r in zip(weights, rems):
            v = kvpr(r, w)
            if v > mx:
                mx = v
        return mx

    # Sort models by importance: high req/slo first, then larger size
    sorted_models = sorted(
        models,
        key=lambda m: (weight_of(m), m.model_size),
        reverse=True
    )

    # Initialize per-GPU states
    placement = {gpu_id: [] for gpu_id in range(gpu_num)}
    remaining_mem = [GPU_MEM_SIZE for _ in range(gpu_num)]
    weights = [0.0 for _ in range(gpu_num)]  # sum of req_rate/slo per GPU

    # Greedy placement with global look-ahead
    eps = 1e-12
    for model in sorted_models:
        w = weight_of(model)
        s = model.model_size

        best_gpu = None
        best_future_max = float('inf')
        best_tie_rem_after = -1

        for g in range(gpu_num):
            if s <= remaining_mem[g]:
                # Simulate placing on GPU g
                rem_after = remaining_mem[g] - s
                w_after = weights[g] + w

                # Compute future max KVPR across all GPUs
                future_max = 0.0
                for i in range(gpu_num):
                    if i == g:
                        v = kvpr(rem_after, w_after)
                    else:
                        v = kvpr(remaining_mem[i], weights[i])
                    if v > future_max:
                        future_max = v

                # Choose the placement that minimizes future maximum KVPR
                if (future_max + eps) < best_future_max:
                    best_future_max = future_max
                    best_gpu = g
                    best_tie_rem_after = rem_after
                elif abs(future_max - best_future_max) <= eps:
                    # Tie-break: prefer more remaining memory after placement
                    if rem_after > best_tie_rem_after:
                        best_gpu = g
                        best_tie_rem_after = rem_after

        if best_gpu is None:
            raise ValueError(
                f"Unable to place model '{getattr(model, 'model_name', '')}' of size {s} GB on any GPU. "
                f"Remaining per-GPU memory: {remaining_mem}"
            )

        placement[best_gpu].append(model)
        remaining_mem[best_gpu] -= s
        weights[best_gpu] += w

    # Local improvement: try single-model moves and pairwise swaps
    def try_single_moves(placement, remaining_mem, weights):
        # Try moving a model from the most loaded GPU to others
        kvprs = [kvpr(remaining_mem[i], weights[i]) for i in range(gpu_num)]
        src = max(range(gpu_num), key=lambda i: kvprs[i])
        current_max = kvprs[src]

        best_gain = 0.0
        best_action = None  # ('move', src, dst, model)
        current_best_new_max = current_max

        # If no models on the bottleneck GPU, nothing to move
        if not placement[src]:
            return False

        for model in placement[src]:
            s = model.model_size
            w = weight_of(model)
            for dst in range(gpu_num):
                if dst == src:
                    continue
                if s <= remaining_mem[dst]:
                    # Simulate move
                    rems = list(remaining_mem)
                    wts = list(weights)

                    # remove from src
                    rems[src] += s
                    wts[src] -= w
                    # add to dst
                    rems[dst] -= s
                    wts[dst] += w

                    new_max = max_kvpr(wts, rems)
                    gain = current_max - new_max
                    if (gain > best_gain + eps) or (abs(gain - best_gain) <= eps and new_max < current_best_new_max):
                        best_gain = gain
                        current_best_new_max = new_max
                        best_action = ('move', src, dst, model)

        if best_action is not None:
            _, src, dst, model = best_action
            # Commit the move
            placement[src].remove(model)
            placement[dst].append(model)
            s = model.model_size
            w = weight_of(model)
            remaining_mem[src] += s
            weights[src] -= w
            remaining_mem[dst] -= s
            weights[dst] += w
            return True
        return False

    def try_swaps(placement, remaining_mem, weights):
        # Try swapping models between the most loaded GPU and others
        kvprs = [kvpr(remaining_mem[i], weights[i]) for i in range(gpu_num)]
        src = max(range(gpu_num), key=lambda i: kvprs[i])
        current_max = max(kvprs) if kvprs else 0.0

        if not placement[src]:
            return False

        best_gain = 0.0
        best_action = None  # ('swap', src, dst, model_src, model_dst)
        best_new_max = current_max

        for dst in range(gpu_num):
            if dst == src or not placement[dst]:
                continue
            for m_src in placement[src]:
                s_src = m_src.model_size
                w_src = weight_of(m_src)
                for m_dst in placement[dst]:
                    s_dst = m_dst.model_size
                    w_dst = weight_of(m_dst)

                    # Check feasibility after swap
                    # After removing m_src from src and adding m_dst:
                    # remaining_mem[src]' = remaining_mem[src] + s_src - s_dst >= 0
                    # After removing m_dst from dst and adding m_src:
                    # remaining_mem[dst]' = remaining_mem[dst] + s_dst - s_src >= 0
                    if (remaining_mem[src] + s_src - s_dst) < 0:
                        continue
                    if (remaining_mem[dst] + s_dst - s_src) < 0:
                        continue

                    # Simulate swap
                    rems = list(remaining_mem)
                    wts = list(weights)

                    rems[src] = remaining_mem[src] + s_src - s_dst
                    wts[src] = weights[src] - w_src + w_dst

                    rems[dst] = remaining_mem[dst] + s_dst - s_src
                    wts[dst] = weights[dst] - w_dst + w_src

                    new_max = max_kvpr(wts, rems)
                    gain = current_max - new_max
                    if (gain > best_gain + eps) or (abs(gain - best_gain) <= eps and new_max < best_new_max):
                        best_gain = gain
                        best_new_max = new_max
                        best_action = ('swap', src, dst, m_src, m_dst)

        if best_action is not None:
            _, src, dst, m_src, m_dst = best_action
            # Commit the swap
            placement[src].remove(m_src)
            placement[dst].append(m_src)
            placement[dst].remove(m_dst)
            placement[src].append(m_dst)

            s_src = m_src.model_size
            w_src = weight_of(m_src)
            s_dst = m_dst.model_size
            w_dst = weight_of(m_dst)

            remaining_mem[src] = remaining_mem[src] + s_src - s_dst
            weights[src] = weights[src] - w_src + w_dst

            remaining_mem[dst] = remaining_mem[dst] + s_dst - s_src
            weights[dst] = weights[dst] - w_dst + w_src
            return True
        return False

    # Perform a few rounds of local search to reduce maximum KVPR
    max_iters = 50
    for _ in range(max_iters):
        improved = False
        if try_single_moves(placement, remaining_mem, weights):
            improved = True
            continue  # re-evaluate from new state
        if try_swaps(placement, remaining_mem, weights):
            improved = True
            continue  # re-evaluate from new state
        if not improved:
            break

    return placement

# EVOLVE-BLOCK-END


if __name__ == "__main__":
    # Test the algorithm

    from evaluator import generate_test_gpu_models
    from evaluator import calculate_kvcache_pressure
    from evaluator import safe_float
    import numpy as np

    test_cases = generate_test_gpu_models()
    all_kvpr = []
    for i, (gpu_num, gpu_models) in enumerate(test_cases):

        results = compute_model_placement(gpu_num, gpu_models)
        max_kvpr = calculate_kvcache_pressure(results)
        all_kvpr.append(safe_float(max_kvpr))

    avg_kvpr = np.mean(all_kvpr)
    if avg_kvpr != 0:
        avg_kvpr = 1.0 / avg_kvpr


    print(f"Max KVPR: {avg_kvpr:.3f}")