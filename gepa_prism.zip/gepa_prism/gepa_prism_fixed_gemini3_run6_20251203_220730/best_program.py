import math
import random

GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Computes a model placement that minimizes the maximum KVPR across all GPUs.
    
    Strategy:
    1.  **Metric Calculation**: Pre-calculates 'pressure weight' (req_rate/slo) for all models.
    2.  **Multi-Strategy Greedy Initialization**: Runs multiple greedy passes with different sorting 
        heuristics (Pressure, Size, Density) and a small amount of randomization to explore 
        different starting states.
    3.  **Look-Ahead Greedy**: During placement, chooses the GPU that results in the lowest *global* 
        maximum KVPR, breaking ties with remaining memory (load balancing).
    4.  **Iterative Refinement (Local Search)**: Uses a hill-climbing approach that specifically 
        targets the bottleneck GPU (highest KVPR). It attempts to:
        - Move a model from the bottleneck GPU to any other GPU.
        - Swap a model from the bottleneck GPU with a model on another GPU.
        - Swap two models between any two GPUs (randomly sampled) if stuck.
    5.  **Safety**: Handles division-by-zero edge cases for full memory.
    """

    # -------------------------------------------------------------------------
    # Helper Functions
    # -------------------------------------------------------------------------
    def get_kvpr(weight_sum, used_mem):
        """Calculates KVPR safely. Returns infinity if memory is full or overcommitted."""
        remaining_mem = GPU_MEM_SIZE - used_mem
        if remaining_mem <= 1e-9: # Treat extremely small remaining memory as full
            return float('inf')
        return weight_sum / remaining_mem

    def calculate_global_max_kvpr(gpu_weights, gpu_used_mem):
        """Returns the maximum KVPR across all GPUs given current state vectors."""
        current_max = -1.0
        for w, m in zip(gpu_weights, gpu_used_mem):
            k = get_kvpr(w, m)
            if k > current_max:
                current_max = k
        return current_max

    # -------------------------------------------------------------------------
    # Core Logic
    # -------------------------------------------------------------------------
    
    # 0. Pre-process models
    model_data = []
    for m in models:
        w = m.req_rate / m.slo
        model_data.append({
            'model': m,
            'weight': w,
            'size': m.model_size,
            'density': w / m.model_size if m.model_size > 0 else 0
        })

    best_global_placement = None
    best_global_max_kvpr = float('inf')

    # 1. Define Sorting Heuristics
    # We mix deterministic strategies with a random shuffle to escape local optima
    # Strategies:
    # 0: Sort by Weight (Descending) - Prioritize high pressure
    # 1: Sort by Size (Descending) - Prioritize big models (Bin Packing intuition)
    # 2: Sort by Density (Descending) - Prioritize high pressure per GB
    # 3: Sort by Size (Ascending) - Fill gaps
    # 4: Random shuffle (run a few times)
    
    strategies = [
        lambda x: x['weight'],             # 0: Weight Desc
        lambda x: x['size'],               # 1: Size Desc
        lambda x: x['density'],            # 2: Density Desc
        lambda x: -x['size'],              # 3: Size Asc
    ]
    
    # Add random seeds for diversity
    # We will run deterministic sorts first, then some random ones
    num_random_trials = 4
    total_trials = len(strategies) + num_random_trials

    for trial_idx in range(total_trials):
        
        # Prepare the list for this trial
        current_models = list(model_data)
        
        if trial_idx < len(strategies):
            # Deterministic Sort
            current_models.sort(key=strategies[trial_idx], reverse=True)
        else:
            # Random Shuffle
            random.shuffle(current_models)

        # ---------------------------------------------------------------------
        # 2. Greedy Construction Phase
        # ---------------------------------------------------------------------
        
        placement = {i: [] for i in range(gpu_num)}
        gpu_weights = [0.0] * gpu_num
        gpu_used_mem = [0.0] * gpu_num
        
        possible = True
        
        for item in current_models:
            model = item['model']
            w = item['weight']
            s = item['size']
            
            best_gpu = -1
            best_score = (float('inf'), float('inf')) # (Global Max KVPR, -Remaining Mem)
            
            # Identify current global max (excluding the changes we are about to make)
            # Optimizing this calculation is key for speed.
            # However, since N_GPU is small, we can just scan.
            
            candidates = []
            
            for g_id in range(gpu_num):
                if gpu_used_mem[g_id] + s <= GPU_MEM_SIZE:
                    # Simulate
                    new_w = gpu_weights[g_id] + w
                    new_m = gpu_used_mem[g_id] + s
                    
                    # Calculate KVPR for this specific GPU
                    my_kvpr = get_kvpr(new_w, new_m)
                    
                    # Estimate Global Max if we pick this GPU
                    # It's max(my_kvpr, max_of_others)
                    # We can compute max_of_others simply by checking the existing vector
                    # minus the current GPU.
                    current_global_max = 0.0
                    for other_g in range(gpu_num):
                        if other_g == g_id: continue
                        k = get_kvpr(gpu_weights[other_g], gpu_used_mem[other_g])
                        if k > current_global_max:
                            current_global_max = k
                    
                    new_global_max = max(my_kvpr, current_global_max)
                    remaining = GPU_MEM_SIZE - new_m
                    
                    candidates.append((new_global_max, -remaining, g_id))
            
            if not candidates:
                possible = False
                break
            
            # Pick best candidate: Minimize Global Max KVPR, then Maximize Remaining Memory
            candidates.sort() # Tuples sort by first element, then second
            best_gpu = candidates[0][2]
            
            # Assign
            placement[best_gpu].append(model)
            gpu_weights[best_gpu] += w
            gpu_used_mem[best_gpu] += s
            
        if not possible:
            continue

        # ---------------------------------------------------------------------
        # 3. Local Search Phase (Iterative Refinement)
        # ---------------------------------------------------------------------
        
        # We perform hill climbing. We find the bottleneck GPU and try to relieve it.
        # If we can't relieve the bottleneck directly, we try random swaps to escape.
        
        max_search_steps = 200
        steps = 0
        improved = True
        
        while improved and steps < max_search_steps:
            improved = False
            steps += 1
            
            # Find Bottleneck
            kvprs = [get_kvpr(gpu_weights[i], gpu_used_mem[i]) for i in range(gpu_num)]
            current_max_kvpr = max(kvprs)
            
            # If KVPR is essentially zero, we are done
            if current_max_kvpr < 1e-9:
                break
                
            bottleneck_gpus = [i for i, k in enumerate(kvprs) if abs(k - current_max_kvpr) < 1e-9]
            # Pick one bottleneck to optimize (randomly if multiple)
            src_gpu = bottleneck_gpus[0] 
            
            src_models = list(placement[src_gpu])
            # Sort models on src to try moving largest/heaviest first? 
            # Actually, moving small 'dense' models might be easier. Let's just shuffle or iterate.
            
            # --- Try MOVE (Relocate) ---
            for model in src_models:
                m_w = model.req_rate / model.slo
                m_s = model.model_size
                
                # Try moving to all other GPUs
                for tgt_gpu in range(gpu_num):
                    if tgt_gpu == src_gpu: continue
                    
                    if gpu_used_mem[tgt_gpu] + m_s <= GPU_MEM_SIZE:
                        # Eval new state
                        # Check src new kvpr
                        src_new_k = get_kvpr(gpu_weights[src_gpu] - m_w, gpu_used_mem[src_gpu] - m_s)
                        # Check tgt new kvpr
                        tgt_new_k = get_kvpr(gpu_weights[tgt_gpu] + m_w, gpu_used_mem[tgt_gpu] + m_s)
                        
                        # Optimization: We only care if the NEW max of (src, tgt) is strictly less than current_max_kvpr.
                        # AND we must ensure tgt doesn't become a NEW global bottleneck worse than current.
                        
                        local_max = max(src_new_k, tgt_new_k)
                        
                        if local_max < current_max_kvpr - 1e-9:
                            # Potential improvement.
                            # Need to verify we didn't just push tgt above some other existing high GPU
                            # (though unlikely to be higher than current_max_kvpr since we checked local_max < current)
                            # The only case is if there was ANOTHER GPU at current_max_kvpr.
                            # If so, reducing src alone doesn't reduce global max.
                            # But it reduces *total pressure* or *count of bottlenecks*.
                            # Let's check strict global reduction if possible, or accept equality to break ties.
                            
                            # Calculate exact new global max
                            # Temporarily apply
                            gpu_weights[src_gpu] -= m_w
                            gpu_used_mem[src_gpu] -= m_s
                            gpu_weights[tgt_gpu] += m_w
                            gpu_used_mem[tgt_gpu] += m_s
                            
                            new_global = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
                            
                            if new_global < current_max_kvpr - 1e-9:
                                # Improvement Found!
                                placement[src_gpu].remove(model)
                                placement[tgt_gpu].append(model)
                                improved = True
                                break # Break inner loop to restart logic with new state
                            else:
                                # Revert
                                gpu_weights[src_gpu] += m_w
                                gpu_used_mem[src_gpu] += m_s
                                gpu_weights[tgt_gpu] -= m_w
                                gpu_used_mem[tgt_gpu] -= m_s
                
                if improved: break
            
            if improved: continue

            # --- Try SWAP ---
            # Swap a model from Bottleneck with a model from another GPU
            for model_a in src_models:
                wa = model_a.req_rate / model_a.slo
                sa = model_a.model_size
                
                for tgt_gpu in range(gpu_num):
                    if tgt_gpu == src_gpu: continue
                    
                    # Optimization: Don't swap with a GPU that is already near max if it makes it worse
                    # Iterate target models
                    tgt_models = list(placement[tgt_gpu])
                    for model_b in tgt_models:
                        wb = model_b.req_rate / model_b.slo
                        sb = model_b.model_size
                        
                        # Check capacity
                        new_u_src = gpu_used_mem[src_gpu] - sa + sb
                        new_u_tgt = gpu_used_mem[tgt_gpu] - sb + sa
                        
                        if new_u_src <= GPU_MEM_SIZE and new_u_tgt <= GPU_MEM_SIZE:
                            new_w_src = gpu_weights[src_gpu] - wa + wb
                            new_w_tgt = gpu_weights[tgt_gpu] - wb + wa
                            
                            k_src = get_kvpr(new_w_src, new_u_src)
                            k_tgt = get_kvpr(new_w_tgt, new_u_tgt)
                            
                            local_max = max(k_src, k_tgt)
                            
                            if local_max < current_max_kvpr - 1e-9:
                                # Apply temp
                                gpu_weights[src_gpu] = new_w_src
                                gpu_used_mem[src_gpu] = new_u_src
                                gpu_weights[tgt_gpu] = new_w_tgt
                                gpu_used_mem[tgt_gpu] = new_u_tgt
                                
                                new_global = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
                                
                                if new_global < current_max_kvpr - 1e-9:
                                    placement[src_gpu].remove(model_a)
                                    placement[src_gpu].append(model_b)
                                    placement[tgt_gpu].remove(model_b)
                                    placement[tgt_gpu].append(model_a)
                                    improved = True
                                    break
                                else:
                                    # Revert
                                    gpu_weights[src_gpu] = gpu_weights[src_gpu] + wa - wb
                                    gpu_used_mem[src_gpu] = gpu_used_mem[src_gpu] + sa - sb
                                    gpu_weights[tgt_gpu] = gpu_weights[tgt_gpu] + wb - wa
                                    gpu_used_mem[tgt_gpu] = gpu_used_mem[tgt_gpu] + sb - sa
                    if improved: break
                if improved: break
            
            if improved: continue
            
            # --- Try 3-Way Shuffle or General Swap (Last Resort) ---
            # If we are stuck in a local minima where the bottleneck can't swap directly to improve,
            # maybe swapping two NON-bottleneck GPUs helps rearrange space for the bottleneck later?
            # Or maybe swapping a small model on bottleneck for a slightly smaller model on target
            # that barely changes bottleneck but opens up capacity?
            # For simplicity and speed, we stop here. The randomized restart (outer loop) covers other bases.
            
        # End of Local Search
        final_max = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
        if final_max < best_global_max_kvpr:
            best_global_max_kvpr = final_max
            # Deep copy result
            best_global_placement = {k: list(v) for k, v in placement.items()}

    if best_global_placement is None:
        # Fallback (e.g., if constraints are extremely tight and randomization failed, though unlikely)
        # Return empty structure or original greedy
        return {i: [] for i in range(gpu_num)}

    return best_global_placement

# EVOLVE-BLOCK-END