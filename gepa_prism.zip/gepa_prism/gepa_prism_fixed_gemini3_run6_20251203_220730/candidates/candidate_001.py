import math

GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.
    
    This implementation uses a heuristic combining:
    1. Intelligent Sorting: Prioritize "dense" models (high pressure/size) and large models.
    2. Best-Fit Greedy with Global Objective: Place models to minimize the instantaneous 
       global maximum KVPR, rather than just the target GPU's KVPR.
    3. Iterative Local Search: Perform moves and swaps to escape local optima.
    """
    
    # -------------------------------------------------------------------------
    # Helper Functions
    # -------------------------------------------------------------------------
    
    def get_kvpr(weight_sum, used_mem):
        """Calculates KVPR safely."""
        remaining_mem = GPU_MEM_SIZE - used_mem
        if remaining_mem <= 0:
            return float('inf')
        return weight_sum / remaining_mem

    def calculate_global_max_kvpr(gpu_weights, gpu_used_mem):
        """Returns the maximum KVPR across all GPUs given current state."""
        max_k = -1.0
        for w, m in zip(gpu_weights, gpu_used_mem):
            k = get_kvpr(w, m)
            if k > max_k:
                max_k = k
        return max_k

    # -------------------------------------------------------------------------
    # Step 1: Sorting Strategy
    # -------------------------------------------------------------------------
    # We sort primarily by the model's contribution to pressure density (rate/slo),
    # and secondarily by size to fit large rocks first.
    # Metric: (req_rate / slo) is the numerator contribution.
    # Placing high numerator items is critical.
    sorted_models = sorted(
        models, 
        key=lambda m: (m.req_rate / m.slo, m.model_size), 
        reverse=True
    )

    # -------------------------------------------------------------------------
    # Step 2: Initialization
    # -------------------------------------------------------------------------
    placement = {i: [] for i in range(gpu_num)}
    gpu_weights = [0.0] * gpu_num      # Sum of (req_rate / slo)
    gpu_used_mem = [0.0] * gpu_num     # Sum of model_size

    # -------------------------------------------------------------------------
    # Step 3: Greedy Construction
    # -------------------------------------------------------------------------
    for model in sorted_models:
        model_weight = model.req_rate / model.slo
        model_size = model.model_size
        
        best_gpu_id = -1
        best_global_max_kvpr = float('inf')
        # Tie-breaker: maximize remaining memory on the target GPU to leave room
        best_target_remaining_mem = -1.0 

        # Try placing current model on each GPU
        candidates = []
        for gpu_id in range(gpu_num):
            # Check physical constraint
            if gpu_used_mem[gpu_id] + model_size <= GPU_MEM_SIZE:
                
                # Simulate state change
                new_weight = gpu_weights[gpu_id] + model_weight
                new_used = gpu_used_mem[gpu_id] + model_size
                
                # Calculate the specific KVPR for this GPU
                current_gpu_kvpr = get_kvpr(new_weight, new_used)
                
                # Determine what the global max would be if we did this
                # It's either the new KVPR of this GPU, or the existing max of others
                # Optimization: We don't need to re-scan all GPUs, just compare against current max
                # However, since current max might be *this* GPU before addition, we need to be careful.
                # To be safe and simple, let's just compute the vector max.
                
                # Temporarily update state
                old_w = gpu_weights[gpu_id]
                old_m = gpu_used_mem[gpu_id]
                gpu_weights[gpu_id] = new_weight
                gpu_used_mem[gpu_id] = new_used
                
                global_max = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
                
                # Revert state
                gpu_weights[gpu_id] = old_w
                gpu_used_mem[gpu_id] = old_m
                
                candidates.append((global_max, GPU_MEM_SIZE - new_used, gpu_id))

        if not candidates:
             raise ValueError(f"Cannot place model {model.model_name} (Size: {model.model_size}) on any GPU.")

        # Sort candidates:
        # 1. Minimize global max KVPR
        # 2. Maximize remaining memory (keeps options open)
        candidates.sort(key=lambda x: (x[0], -x[1]))
        
        best_gpu_id = candidates[0][2]
        
        # Commit placement
        placement[best_gpu_id].append(model)
        gpu_weights[best_gpu_id] += model_weight
        gpu_used_mem[best_gpu_id] += model_size

    # -------------------------------------------------------------------------
    # Step 4: Local Search Refinement
    # -------------------------------------------------------------------------
    # Attempt to move models from the bottleneck GPU (highest KVPR) to others.
    # Or swap models between bottleneck GPU and others.
    
    max_iterations = 100  # Cap iterations to ensure speed
    improved = True
    
    while improved and max_iterations > 0:
        improved = False
        max_iterations -= 1
        
        # Identify current bottleneck
        current_kvprs = [get_kvpr(w, m) for w, m in zip(gpu_weights, gpu_used_mem)]
        max_kvpr = max(current_kvprs)
        bottleneck_gpu = current_kvprs.index(max_kvpr)
        
        # Strategy A: Try to MOVE a model from bottleneck GPU to another GPU
        # Sort models on bottleneck GPU by size (maybe smaller ones fit elsewhere easier) or weight
        bottleneck_models = list(placement[bottleneck_gpu])
        # Try moving 'heaviest' contributors first? Or smallest size? 
        # Let's try iterating all.
        
        for model in bottleneck_models:
            model_w = model.req_rate / model.slo
            model_s = model.model_size
            
            # Try moving to every other GPU
            for target_gpu in range(gpu_num):
                if target_gpu == bottleneck_gpu:
                    continue
                
                if gpu_used_mem[target_gpu] + model_s <= GPU_MEM_SIZE:
                    # Calculate new states
                    src_w_new = gpu_weights[bottleneck_gpu] - model_w
                    src_m_new = gpu_used_mem[bottleneck_gpu] - model_s
                    
                    tgt_w_new = gpu_weights[target_gpu] + model_w
                    tgt_m_new = gpu_used_mem[target_gpu] + model_s
                    
                    kvpr_src_new = get_kvpr(src_w_new, src_m_new)
                    kvpr_tgt_new = get_kvpr(tgt_w_new, tgt_m_new)
                    
                    # We accept the move if the new max of (src, tgt) is strictly better than old max KVPR
                    # AND we don't create a new global maximum higher than the current max_kvpr elsewhere
                    
                    # Check if we improved the local situation without blowing up the target
                    new_local_max = max(kvpr_src_new, kvpr_tgt_new)
                    
                    if new_local_max < max_kvpr:
                        # Only proceed if we didn't just shift the bottleneck to be worse than before
                        # The old max was 'max_kvpr'. If new_local_max is smaller, we *might* have improved.
                        # We need to ensure we didn't exceed max_kvpr on the target (checked implicitly)
                        # and that no OTHER gpu was sitting at max_kvpr (if so, we didn't actually reduce global max)
                        
                        # Apply move temporarily to check global stats
                        placement[bottleneck_gpu].remove(model)
                        placement[target_gpu].append(model)
                        gpu_weights[bottleneck_gpu] = src_w_new
                        gpu_used_mem[bottleneck_gpu] = src_m_new
                        gpu_weights[target_gpu] = tgt_w_new
                        gpu_used_mem[target_gpu] = tgt_m_new
                        
                        new_global_max = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
                        
                        if new_global_max < max_kvpr - 1e-9: # floating point tolerance
                            improved = True
                            break # Restart loop with new state
                        else:
                            # Revert
                            placement[target_gpu].pop()
                            placement[bottleneck_gpu].append(model)
                            gpu_weights[bottleneck_gpu] += model_w
                            gpu_used_mem[bottleneck_gpu] += model_s
                            gpu_weights[target_gpu] -= model_w
                            gpu_used_mem[target_gpu] -= model_s
            
            if improved: break
        
        if improved: continue

        # Strategy B: Try to SWAP a model from bottleneck GPU with a model from another GPU
        # Only try if MOVE failed
        for model_a in bottleneck_models:
            wa = model_a.req_rate / model_a.slo
            sa = model_a.model_size
            
            for target_gpu in range(gpu_num):
                if target_gpu == bottleneck_gpu: continue
                
                # Check models on target GPU
                target_models = list(placement[target_gpu])
                for model_b in target_models:
                    wb = model_b.req_rate / model_b.slo
                    sb = model_b.model_size
                    
                    # Check capacity constraints for swap
                    new_used_bottleneck = gpu_used_mem[bottleneck_gpu] - sa + sb
                    new_used_target = gpu_used_mem[target_gpu] - sb + sa
                    
                    if new_used_bottleneck <= GPU_MEM_SIZE and new_used_target <= GPU_MEM_SIZE:
                         # Calculate new weights
                        new_weight_bottleneck = gpu_weights[bottleneck_gpu] - wa + wb
                        new_weight_target = gpu_weights[target_gpu] - wb + wa
                        
                        k_bot = get_kvpr(new_weight_bottleneck, new_used_bottleneck)
                        k_tgt = get_kvpr(new_weight_target, new_used_target)
                        
                        new_local_max = max(k_bot, k_tgt)
                        
                        if new_local_max < max_kvpr:
                            # Apply swap temporarily
                            placement[bottleneck_gpu].remove(model_a)
                            placement[bottleneck_gpu].append(model_b)
                            placement[target_gpu].remove(model_b)
                            placement[target_gpu].append(model_a)
                            
                            # Update tracking vars
                            gpu_weights[bottleneck_gpu] = new_weight_bottleneck
                            gpu_used_mem[bottleneck_gpu] = new_used_bottleneck
                            gpu_weights[target_gpu] = new_weight_target
                            gpu_used_mem[target_gpu] = new_used_target
                            
                            new_global_max = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
                            
                            if new_global_max < max_kvpr - 1e-9:
                                improved = True
                                break
                            else:
                                # Revert swap
                                placement[bottleneck_gpu].remove(model_b)
                                placement[bottleneck_gpu].append(model_a)
                                placement[target_gpu].remove(model_a)
                                placement[target_gpu].append(model_b)
                                
                                gpu_weights[bottleneck_gpu] += wa - wb
                                gpu_used_mem[bottleneck_gpu] += sa - sb
                                gpu_weights[target_gpu] += wb - wa
                                gpu_used_mem[target_gpu] += sb - sa
                if improved: break
            if improved: break

    return placement

# EVOLVE-BLOCK-END