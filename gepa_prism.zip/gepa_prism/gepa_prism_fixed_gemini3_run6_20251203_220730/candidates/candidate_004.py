import math
import random

GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Computes a model placement that minimizes the maximum KVPR across all GPUs.
    
    KVPR = (Sum of req_rate/slo) / (GPU_MEM_SIZE - Sum of model_size)
    
    Improvements over baseline:
    1.  **Enhanced Objective**: Optimizes (Max KVPR, L2 Norm of KVPRs, Remaining Mem) to break ties 
        and reduce overall system pressure, preventing secondary bottlenecks.
    2.  **Plateau Walking**: Local search accepts moves that don't strictly decrease the Max KVPR 
        but decrease the sum of squares of KVPRs, allowing the algorithm to escape local optima 
        where multiple GPUs are tied for the maximum.
    3.  **Diverse Initialization**: Runs more random trials and utilizes specific sorting heuristics 
        (Density, Weight, Size) to explore the solution space.
    """

    # -------------------------------------------------------------------------
    # Helper Functions
    # -------------------------------------------------------------------------
    def get_kvpr_and_rem(weight_sum, used_mem):
        """Calculates KVPR and remaining memory. Returns infinity if memory is full."""
        remaining_mem = GPU_MEM_SIZE - used_mem
        if remaining_mem <= 1e-9:
            return float('inf'), 0.0
        return weight_sum / remaining_mem, remaining_mem

    def evaluate_state(gpu_weights, gpu_used_mem):
        """
        Returns a tuple (max_kvpr, sum_sq_kvpr) for the system state.
        Lower is better for both.
        """
        max_k = -1.0
        sum_sq = 0.0
        for w, m in zip(gpu_weights, gpu_used_mem):
            k, _ = get_kvpr_and_rem(w, m)
            if k == float('inf'):
                return float('inf'), float('inf')
            if k > max_k:
                max_k = k
            sum_sq += k * k
        return max_k, sum_sq

    # -------------------------------------------------------------------------
    # Data Preparation
    # -------------------------------------------------------------------------
    # Pre-calculate model weights (pressure)
    model_data = []
    for m in models:
        w = m.req_rate / m.slo
        model_data.append({
            'model': m,
            'weight': w,
            'size': m.model_size,
            'density': w / m.model_size if m.model_size > 0 else 0
        })

    best_placement = {i: [] for i in range(gpu_num)}
    best_state_score = (float('inf'), float('inf')) # (Max KVPR, Sum Sq)

    # -------------------------------------------------------------------------
    # Heuristics Definition
    # -------------------------------------------------------------------------
    # Heuristic strategies for sorting models before greedy placement
    strategies = [
        lambda x: x['weight'],             # 0: Heavy models first (High Pressure)
        lambda x: x['density'],            # 1: High pressure/GB first
        lambda x: x['size'],               # 2: Big models first (Bin Packing)
        lambda x: (x['weight'], x['size']),# 3: Heavy then Big
        lambda x: x['weight'] * x['size'], # 4: Combined impact
    ]
    
    # Increase random trials for better coverage
    num_random_trials = 15
    total_trials = len(strategies) + num_random_trials

    # -------------------------------------------------------------------------
    # Optimization Loop
    # -------------------------------------------------------------------------
    for trial_idx in range(total_trials):
        
        # 1. Initialization
        current_models = list(model_data)
        
        if trial_idx < len(strategies):
            # Deterministic sorts
            # For tuple sort keys (strategy 3), python handles it naturally
            current_models.sort(key=strategies[trial_idx], reverse=True)
        else:
            # Random shuffle
            random.shuffle(current_models)

        # 2. Greedy Construction with Look-Ahead
        placement = {i: [] for i in range(gpu_num)}
        gpu_weights = [0.0] * gpu_num
        gpu_used_mem = [0.0] * gpu_num
        current_kvprs = [0.0] * gpu_num # Track running KVPRs to speed up lookahead
        
        possible = True
        
        for item in current_models:
            model = item['model']
            w = item['weight']
            s = item['size']
            
            candidates = []
            
            for g_id in range(gpu_num):
                if gpu_used_mem[g_id] + s <= GPU_MEM_SIZE:
                    # Simulate adding model to GPU g_id
                    new_w = gpu_weights[g_id] + w
                    new_m = gpu_used_mem[g_id] + s
                    new_kvpr, rem = get_kvpr_and_rem(new_w, new_m)
                    
                    if new_kvpr == float('inf'):
                        continue

                    # Calculate hypothetical Global Max and Sum Sq
                    # We can do this incrementally without re-looping all GPUs
                    # Current Global Max = max(new_kvpr, max(other_kvprs))
                    
                    temp_max_k = new_kvpr
                    temp_sum_sq = new_kvpr * new_kvpr
                    
                    for other_g in range(gpu_num):
                        if other_g == g_id: continue
                        k = current_kvprs[other_g]
                        if k > temp_max_k:
                            temp_max_k = k
                        temp_sum_sq += k * k
                    
                    # Store candidate: (Max KVPR, Sum Sq, -Remaining Mem, GPU ID)
                    # We want to minimize Max KVPR, then Sum Sq, then maximize Remaining Mem
                    candidates.append((temp_max_k, temp_sum_sq, -rem, g_id))
            
            if not candidates:
                possible = False
                break
            
            # Pick best candidate
            candidates.sort() # Tuple comparison handles priority
            best_g = candidates[0][3]
            
            # Commit
            placement[best_g].append(model)
            gpu_weights[best_g] += w
            gpu_used_mem[best_g] += s
            # Update cached KVPR
            k, _ = get_kvpr_and_rem(gpu_weights[best_g], gpu_used_mem[best_g])
            current_kvprs[best_g] = k
            
        if not possible:
            continue

        # 3. Local Search (Iterative Improvement)
        # We try to improve (Max KVPR, Sum Sq) tuple
        
        current_score = evaluate_state(gpu_weights, gpu_used_mem) # (max_k, sum_sq)
        
        improved = True
        steps = 0
        max_steps = 150 # Cap iterations
        
        while improved and steps < max_steps:
            improved = False
            steps += 1
            
            # Identify Bottlenecks
            # We target GPUs that are close to the current max
            kvprs = [get_kvpr_and_rem(gpu_weights[i], gpu_used_mem[i])[0] for i in range(gpu_num)]
            current_max = max(kvprs)
            
            if current_max < 1e-9:
                break
                
            # Candidates to relieve: any GPU within 1% of max
            bottleneck_indices = [i for i, k in enumerate(kvprs) if k >= current_max * 0.99]
            
            # Randomize order of bottlenecks to visit to avoid cycles
            random.shuffle(bottleneck_indices)
            
            for src_gpu in bottleneck_indices:
                src_models = list(placement[src_gpu])
                # Sort models by size or weight? Let's just shuffle to be stochastic
                random.shuffle(src_models)
                
                # Try MOVE
                for model in src_models:
                    m_w = model.req_rate / model.slo
                    m_s = model.model_size
                    
                    for tgt_gpu in range(gpu_num):
                        if tgt_gpu == src_gpu: continue
                        
                        if gpu_used_mem[tgt_gpu] + m_s <= GPU_MEM_SIZE:
                            # Apply Move
                            gpu_weights[src_gpu] -= m_w
                            gpu_used_mem[src_gpu] -= m_s
                            gpu_weights[tgt_gpu] += m_w
                            gpu_used_mem[tgt_gpu] += m_s
                            
                            new_score = evaluate_state(gpu_weights, gpu_used_mem)
                            
                            # Acceptance criteria: Strictly better Max, OR Equal Max but better Sum Sq
                            # Floating point tolerance needed
                            
                            better_max = new_score[0] < current_score[0] - 1e-9
                            equal_max = abs(new_score[0] - current_score[0]) < 1e-9
                            better_sum = new_score[1] < current_score[1] - 1e-9
                            
                            if better_max or (equal_max and better_sum):
                                # Commit
                                placement[src_gpu].remove(model)
                                placement[tgt_gpu].append(model)
                                current_score = new_score
                                improved = True
                                break # Restart loop
                            else:
                                # Revert
                                gpu_weights[src_gpu] += m_w
                                gpu_used_mem[src_gpu] += m_s
                                gpu_weights[tgt_gpu] -= m_w
                                gpu_used_mem[tgt_gpu] -= m_s
                    if improved: break
                if improved: break
                
                # Try SWAP
                # Swap model from src_gpu (bottleneck) with model from tgt_gpu (non-bottleneck)
                for model_a in src_models:
                    wa = model_a.req_rate / model_a.slo
                    sa = model_a.model_size
                    
                    for tgt_gpu in range(gpu_num):
                        if tgt_gpu == src_gpu: continue
                        
                        # Optimization: only swap with GPUs that are NOT bottlenecks themselves
                        # or at least significantly lower than src
                        if kvprs[tgt_gpu] > current_max * 0.99:
                            continue

                        tgt_models = list(placement[tgt_gpu])
                        for model_b in tgt_models:
                            wb = model_b.req_rate / model_b.slo
                            sb = model_b.model_size
                            
                            new_u_src = gpu_used_mem[src_gpu] - sa + sb
                            new_u_tgt = gpu_used_mem[tgt_gpu] - sb + sa
                            
                            if new_u_src <= GPU_MEM_SIZE and new_u_tgt <= GPU_MEM_SIZE:
                                # Apply Swap
                                gpu_weights[src_gpu] = gpu_weights[src_gpu] - wa + wb
                                gpu_used_mem[src_gpu] = gpu_used_mem[src_gpu] - sa + sb
                                gpu_weights[tgt_gpu] = gpu_weights[tgt_gpu] - wb + wa
                                gpu_used_mem[tgt_gpu] = gpu_used_mem[tgt_gpu] - sb + sa
                                
                                new_score = evaluate_state(gpu_weights, gpu_used_mem)
                                
                                better_max = new_score[0] < current_score[0] - 1e-9
                                equal_max = abs(new_score[0] - current_score[0]) < 1e-9
                                better_sum = new_score[1] < current_score[1] - 1e-9
                                
                                if better_max or (equal_max and better_sum):
                                    placement[src_gpu].remove(model_a)
                                    placement[src_gpu].append(model_b)
                                    placement[tgt_gpu].remove(model_b)
                                    placement[tgt_gpu].append(model_a)
                                    current_score = new_score
                                    improved = True
                                    break
                                else:
                                    # Revert
                                    gpu_weights[src_gpu] = gpu_weights[src_gpu] + wa - wb
                                    gpu_used_mem[src_gpu] = gpu_used_mem[src_gpu] + sa - sb
                                    gpu_weights[tgt_gpu] = gpu_weights[tgt_gpu] + wb - wa
                                    gpu_used_mem[tgt_gpu] = gpu_used_mem[tgt_gpu] + sb - sa
                        if improved: break
                    if improved: break
                if improved: break

        # 4. Record Global Best
        # current_score is (Max KVPR, Sum Sq)
        # We compare lexicographically
        if current_score < best_state_score:
            best_state_score = current_score
            best_placement = {k: list(v) for k, v in placement.items()}

    return best_placement

# EVOLVE-BLOCK-END