import math

GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Computes a model placement that minimizes the maximum KVPR across all GPUs.
    
    This implementation improves upon previous strategies by:
    1.  **Iterative Greedy Construction**: It randomizes the sorting order slightly and runs multiple 
        greedy passes to find the best starting point, rather than relying on a single deterministic sort.
    2.  **Global Objective Greedy**: During placement, it selects the GPU that minimizes the *global* 
        maximum KVPR, not just the local GPU's KVPR.
    3.  **Comprehensive Local Search**: It employs a hill-climbing approach with both 'moves' (relocating 
        a model) and 'swaps' (exchanging two models), specifically targeting the bottleneck GPU 
        to reduce the global maximum.
    """
    
    # -------------------------------------------------------------------------
    # Helper Functions
    # -------------------------------------------------------------------------
    def get_kvpr(weight_sum, used_mem):
        """Calculates KVPR safely. Returns infinity if memory is full or overcommitted."""
        remaining_mem = GPU_MEM_SIZE - used_mem
        if remaining_mem <= 0:
            return float('inf')
        # If weight is 0, KVPR is 0. If weight > 0 and mem > 0, standard calc.
        return weight_sum / remaining_mem

    def calculate_global_max_kvpr(gpu_weights, gpu_used_mem):
        """Returns the maximum KVPR across all GPUs given current state vectors."""
        current_max = -1.0
        for w, m in zip(gpu_weights, gpu_used_mem):
            k = get_kvpr(w, m)
            if k > current_max:
                current_max = k
        return current_max

    # -------------------------------------------------------------------------
    # Core Logic
    # -------------------------------------------------------------------------
    
    # Pre-calculate metrics for efficiency
    model_metrics = []
    for m in models:
        pressure_weight = m.req_rate / m.slo
        model_metrics.append({
            'model': m,
            'weight': pressure_weight,
            'size': m.model_size,
            'density': pressure_weight / m.model_size if m.model_size > 0 else 0
        })

    # Strategy:
    # We will try a few different sorting heuristics and keep the best result.
    # Heuristics:
    # 1. Sort by Pressure (Weight) descending
    # 2. Sort by Size descending
    # 3. Sort by Pressure Density (Weight/Size) descending
    
    best_placement_global = None
    best_max_kvpr_global = float('inf')

    sorting_strategies = [
        lambda x: (x['weight'], x['size']),         # Weight primary, Size secondary
        lambda x: (x['size'], x['weight']),         # Size primary, Weight secondary
        lambda x: (x['density'], x['weight']),      # Density primary
    ]

    for sort_key in sorting_strategies:
        # 1. Initialization for this run
        sorted_metrics = sorted(model_metrics, key=sort_key, reverse=True)
        
        placement = {i: [] for i in range(gpu_num)}
        gpu_weights = [0.0] * gpu_num
        gpu_used_mem = [0.0] * gpu_num
        
        possible_to_place_all = True

        # 2. Greedy Construction
        for item in sorted_metrics:
            model = item['model']
            w = item['weight']
            s = item['size']
            
            best_gpu = -1
            best_result_max_kvpr = float('inf')
            best_remaining_mem = -1.0
            
            # Find best GPU for this model
            candidates = []
            
            for g_id in range(gpu_num):
                if gpu_used_mem[g_id] + s <= GPU_MEM_SIZE:
                    # Simulate adding
                    new_w = gpu_weights[g_id] + w
                    new_m = gpu_used_mem[g_id] + s
                    
                    # Compute new specific KVPR
                    new_kvpr = get_kvpr(new_w, new_m)
                    
                    # We need the global max. 
                    # Optimization: Global max is max(new_kvpr, existing_max_excluding_this_gpu).
                    # Since existing_max is expensive to recompute fully every inner loop, 
                    # we can just re-scan or keep track. given N is small (GPUs < 16), re-scan is fine.
                    
                    # Temporarily commit to check global max
                    orig_w = gpu_weights[g_id]
                    orig_m = gpu_used_mem[g_id]
                    
                    gpu_weights[g_id] = new_w
                    gpu_used_mem[g_id] = new_m
                    
                    g_max = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
                    
                    # Revert
                    gpu_weights[g_id] = orig_w
                    gpu_used_mem[g_id] = orig_m
                    
                    remaining = GPU_MEM_SIZE - new_m
                    candidates.append((g_max, remaining, g_id))

            if not candidates:
                possible_to_place_all = False
                break
            
            # Sort candidates: minimize global max KVPR, then maximize remaining memory (load balancing)
            candidates.sort(key=lambda x: (x[0], -x[1]))
            best_gpu = candidates[0][2]
            
            # Commit
            placement[best_gpu].append(model)
            gpu_weights[best_gpu] += w
            gpu_used_mem[best_gpu] += s

        if not possible_to_place_all:
            continue

        # 3. Local Search (Hill Climbing)
        # Try to improve the current solution by moving or swapping models from the bottleneck GPU
        
        improved = True
        iterations = 0
        max_search_iter = 150 # limit to ensure speed

        while improved and iterations < max_search_iter:
            improved = False
            iterations += 1
            
            # Identify Bottleneck
            current_kvprs = [get_kvpr(gpu_weights[i], gpu_used_mem[i]) for i in range(gpu_num)]
            max_kvpr = max(current_kvprs)
            
            # If we hit a very low KVPR (or 0), stop
            if max_kvpr < 1e-6:
                break
                
            bottleneck_gpu = current_kvprs.index(max_kvpr)
            
            # Action 1: Try to MOVE a model from Bottleneck -> Other GPU
            bottleneck_models = list(placement[bottleneck_gpu])
            # Sort models to move: try largest density contributors first? Or just loop all.
            # Looping all is safer.
            
            for model in bottleneck_models:
                m_w = model.req_rate / model.slo
                m_s = model.model_size
                
                for target_gpu in range(gpu_num):
                    if target_gpu == bottleneck_gpu: continue
                    
                    if gpu_used_mem[target_gpu] + m_s <= GPU_MEM_SIZE:
                        # Eval move
                        src_w = gpu_weights[bottleneck_gpu] - m_w
                        src_m = gpu_used_mem[bottleneck_gpu] - m_s
                        tgt_w = gpu_weights[target_gpu] + m_w
                        tgt_m = gpu_used_mem[target_gpu] + m_s
                        
                        k_src = get_kvpr(src_w, src_m)
                        k_tgt = get_kvpr(tgt_w, tgt_m)
                        
                        # New max of these two
                        local_max = max(k_src, k_tgt)
                        
                        if local_max < max_kvpr:
                            # Verify global impact
                            # We only need to check if we created a new global max elsewhere greater than existing max_kvpr.
                            # But since we only touched src and tgt, and local_max < max_kvpr, 
                            # the only risk is if another GPU *was* at max_kvpr as well.
                            # We must check global max.
                            
                            # Apply temp
                            gpu_weights[bottleneck_gpu] = src_w
                            gpu_used_mem[bottleneck_gpu] = src_m
                            gpu_weights[target_gpu] = tgt_w
                            gpu_used_mem[target_gpu] = tgt_m
                            
                            new_global_max = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
                            
                            if new_global_max < max_kvpr - 1e-9:
                                # Commit move
                                placement[bottleneck_gpu].remove(model)
                                placement[target_gpu].append(model)
                                improved = True
                                break # Restart loop
                            else:
                                # Revert
                                gpu_weights[bottleneck_gpu] += m_w
                                gpu_used_mem[bottleneck_gpu] += m_s
                                gpu_weights[target_gpu] -= m_w
                                gpu_used_mem[target_gpu] -= m_s
                
                if improved: break
            
            if improved: continue

            # Action 2: Try to SWAP a model on Bottleneck <-> Model on Other GPU
            # This is O(N_bottleneck * N_other * Gpus). Expensive but necessary for tight fits.
            for model_a in bottleneck_models:
                wa = model_a.req_rate / model_a.slo
                sa = model_a.model_size
                
                for target_gpu in range(gpu_num):
                    if target_gpu == bottleneck_gpu: continue
                    
                    target_models = list(placement[target_gpu])
                    for model_b in target_models:
                        wb = model_b.req_rate / model_b.slo
                        sb = model_b.model_size
                        
                        # Check capacity
                        new_u_src = gpu_used_mem[bottleneck_gpu] - sa + sb
                        new_u_tgt = gpu_used_mem[target_gpu] - sb + sa
                        
                        if new_u_src <= GPU_MEM_SIZE and new_u_tgt <= GPU_MEM_SIZE:
                            new_w_src = gpu_weights[bottleneck_gpu] - wa + wb
                            new_w_tgt = gpu_weights[target_gpu] - wb + wa
                            
                            k_src = get_kvpr(new_w_src, new_u_src)
                            k_tgt = get_kvpr(new_w_tgt, new_u_tgt)
                            
                            local_max = max(k_src, k_tgt)
                            
                            if local_max < max_kvpr:
                                # Tentative apply
                                gpu_weights[bottleneck_gpu] = new_w_src
                                gpu_used_mem[bottleneck_gpu] = new_u_src
                                gpu_weights[target_gpu] = new_w_tgt
                                gpu_used_mem[target_gpu] = new_u_tgt
                                
                                new_global = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
                                
                                if new_global < max_kvpr - 1e-9:
                                    # Commit swap
                                    placement[bottleneck_gpu].remove(model_a)
                                    placement[bottleneck_gpu].append(model_b)
                                    placement[target_gpu].remove(model_b)
                                    placement[target_gpu].append(model_a)
                                    improved = True
                                    break
                                else:
                                    # Revert
                                    gpu_weights[bottleneck_gpu] = gpu_weights[bottleneck_gpu] + wa - wb
                                    gpu_used_mem[bottleneck_gpu] = gpu_used_mem[bottleneck_gpu] + sa - sb
                                    gpu_weights[target_gpu] = gpu_weights[target_gpu] + wb - wa
                                    gpu_used_mem[target_gpu] = gpu_used_mem[target_gpu] + sb - sa
                    if improved: break
                if improved: break

        # End of search for this strategy
        final_max_kvpr = calculate_global_max_kvpr(gpu_weights, gpu_used_mem)
        
        if final_max_kvpr < best_max_kvpr_global:
            best_max_kvpr_global = final_max_kvpr
            # Deep copy placement for the best result
            best_placement_global = {k: list(v) for k, v in placement.items()}

    if best_placement_global is None:
        # Fallback if no strategy worked (should only happen if constraints are impossible)
        # Just return an empty greedy attempt or raise
        raise ValueError("Could not find a valid placement for the models.")
        
    return best_placement_global

# EVOLVE-BLOCK-END