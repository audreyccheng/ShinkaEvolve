GPU_MEM_SIZE = 80  # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.

    KVPR(GPU i) = sum_j (req_rate_j / slo_j) / (GPU_MEM_SIZE - sum_j(model_size_j))
    If remaining memory is 0 or less, KVPR is treated as infinity.

    Args:
        gpu_num: Number of GPUs
        models: List of models to place

    Returns:
        A placement dict: {gpu_id: [Model, ...]}
    """

    # Helpers
    def model_pressure(m):
        if m.slo is None or m.slo == 0:
            return float('inf')
        return m.req_rate / m.slo

    def kvpr(weight, rem_mem):
        return float('inf') if rem_mem <= 0 else (weight / rem_mem)

    def calc_max_kvpr(weights, rems):
        max_val = 0.0
        for i in range(len(weights)):
            v = kvpr(weights[i], rems[i])
            if v > max_val:
                max_val = v
        return max_val

    # Edge cases and pre-checks
    if gpu_num <= 0:
        if len(models) == 0:
            return {}
        raise ValueError("No GPUs available to place models.")

    # Precompute sizes and weights
    items = []
    total_size = 0
    total_w = 0.0
    for m in models:
        s = getattr(m, 'model_size', None)
        if s is None:
            raise ValueError("Model missing model_size attribute.")
        if s > GPU_MEM_SIZE:
            raise ValueError(f"Model {getattr(m, 'model_name', '?')} size {s} exceeds GPU capacity {GPU_MEM_SIZE}.")
        w = model_pressure(m)
        if w == float('inf'):
            # If a model has zero SLO (infinite pressure), it's still placeable only if it occupies less than MEM.
            # But any placement with w>0 and remaining==0 leads to inf KVPR.
            pass
        items.append((m, s, w))
        total_size += s
        total_w += 0.0 if w == float('inf') else w  # This sum is only used for bounds; inf handled separately

    # Check global memory feasibility
    if total_size > gpu_num * GPU_MEM_SIZE:
        raise ValueError("Total model sizes exceed total available GPU memory.")

    # Special simple case: all models have zero pressure (req_rate/slo == 0). KVPR will be 0.
    # Place by memory only (Best Fit Decreasing by size).
    all_zero_pressure = all((model_pressure(m) == 0.0) for m in models)
    if all_zero_pressure:
        # Memory-only BFD
        placement = {i: [] for i in range(gpu_num)}
        rem_mem = [GPU_MEM_SIZE] * gpu_num
        # Sort by size descending
        for m, s, _ in sorted(items, key=lambda x: x[1], reverse=True):
            best = None
            best_delta = None
            for i in range(gpu_num):
                if rem_mem[i] >= s:
                    delta = rem_mem[i] - s
                    if best is None or delta < best_delta or (delta == best_delta and i < best):
                        best = i
                        best_delta = delta
            if best is None:
                # Should not happen due to global feasibility check
                raise ValueError("Unable to place model in zero-pressure case.")
            placement[best].append(m)
            rem_mem[best] -= s
        return placement

    # Greedy placement to get a valid upper bound for KVPR
    def greedy_upper_bound_placement():
        # Sort models: high pressure first, then by size
        sorted_models = sorted(items, key=lambda x: (x[2], x[1]), reverse=True)
        placement = {i: [] for i in range(gpu_num)}
        remaining = [GPU_MEM_SIZE for _ in range(gpu_num)]
        weights = [0.0 for _ in range(gpu_num)]
        for m, s, w in sorted_models:
            best_choice = None  # (future_max_kvpr, -rem_after, curr_weight, gpu_id)
            for i in range(gpu_num):
                if s <= remaining[i]:
                    new_rem_i = remaining[i] - s
                    new_w_i = weights[i] + (0.0 if w == float('inf') else w)

                    fut_max = 0.0
                    for j in range(gpu_num):
                        if j == i:
                            v = kvpr(new_w_i, new_rem_i)
                        else:
                            v = kvpr(weights[j], remaining[j])
                        if v > fut_max:
                            fut_max = v

                    candidate = (fut_max, -new_rem_i, weights[i], i)
                    if best_choice is None or candidate < best_choice:
                        best_choice = candidate
            if best_choice is None:
                raise ValueError("Greedy UB: unable to place a model due to memory constraints.")
            _, _, _, chosen = best_choice
            placement[chosen].append(m)
            remaining[chosen] -= s
            if w != float('inf'):
                weights[chosen] += w
            else:
                # Approximate with a very large weight to reflect pressure
                weights[chosen] += 1e12
        ub = calc_max_kvpr(weights, remaining)
        return placement, ub

    # Bin packing with transformed sizes a_T(m) = w + T * s and bin capacity C(T) = T * MEM
    # Also enforce memory constraint per GPU.
    def pack_with_T(T):
        C = T * GPU_MEM_SIZE
        # Sort by transformed size descending, tie by memory size and weight
        transformed = []
        for m, s, w in items:
            # For infinite w, ensure transformed size is infinite unless T is huge.
            if w == float('inf'):
                a = float('inf')
            else:
                a = w + T * s
            transformed.append((a, s, w, m))
        transformed.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)

        placement = {i: [] for i in range(gpu_num)}
        rem_cap = [C for _ in range(gpu_num)]
        rem_mem = [GPU_MEM_SIZE for _ in range(gpu_num)]
        weights = [0.0 for _ in range(gpu_num)]

        for a, s, w, m in transformed:
            best = None
            best_delta = None
            for i in range(gpu_num):
                # Check both transformed capacity and real memory capacity
                if rem_mem[i] >= s:
                    # Treat inf a as impossible unless bin empty and memory allows and w==inf?
                    # If w is inf, KVPR will be infinite unless rem_mem is infinite; so infeasible overall.
                    # We prevent placing any inf-w item by transformed capacity, since a is inf.
                    if a == float('inf'):
                        continue
                    if rem_cap[i] + 1e-12 >= a:  # allow tiny numerical tolerance
                        delta = rem_cap[i] - a
                        if best is None or delta < best_delta or (delta == best_delta and i < best):
                            best = i
                            best_delta = delta
            if best is None:
                return False, None, None, None
            placement[best].append(m)
            rem_cap[best] -= a
            rem_mem[best] -= s
            if w != float('inf'):
                weights[best] += w
            else:
                weights[best] += 1e12
        return True, placement, weights, rem_mem

    # Compute lower bound
    total_rem_global = gpu_num * GPU_MEM_SIZE - total_size
    if total_rem_global <= 0:
        raise ValueError("No remaining memory globally; placement impossible.")
    lb = (total_w / total_rem_global) if total_w > 0 else 0.0

    # Individual feasibility bound to ensure each item can fit into an empty bin
    tcrit = 0.0
    for m, s, w in items:
        if s >= GPU_MEM_SIZE:
            # If s == GPU_MEM_SIZE and w > 0, KVPR would be inf and infeasible.
            if s > GPU_MEM_SIZE or (s == GPU_MEM_SIZE and w > 0):
                raise ValueError("A model occupies full GPU memory with positive pressure: infeasible.")
            # if s == MEM and w == 0, it's fine but only one per GPU.
        if w == float('inf'):
            # Cannot be satisfied with any finite T unless s < MEM and w==0 which isn't the case here; infeasible.
            raise ValueError("A model has infinite pressure (slo==0), infeasible for finite KVPR.")
        denom = max(1e-12, (GPU_MEM_SIZE - s))
        tcrit = max(tcrit, w / denom)
    tcrit = max(tcrit, 0.0)

    # Upper bound via greedy placement
    greedy_place, ub_greedy = greedy_upper_bound_placement()
    # If greedy produced NaN or inf (extreme edge), fallback to conservative bound
    if ub_greedy != ub_greedy or ub_greedy == float('inf'):
        ub_greedy = max(10.0, tcrit * 2 + 1.0)

    left = max(lb, 0.0)
    right = max(ub_greedy, left, tcrit)

    # Ensure pack_with_T is feasible at 'right'; if not, grow right exponentially.
    feasible, best_place, best_weights, best_rem = pack_with_T(right)
    grow_guard = 0
    while not feasible and grow_guard < 20:
        right = max(1.5 * right + 1e-3, right + 1.0)
        feasible, best_place, best_weights, best_rem = pack_with_T(right)
        grow_guard += 1
    # If still not feasible (shouldn't happen), fall back to greedy placement
    if not feasible:
        placement = greedy_place
    else:
        # Binary search to tighten T
        for _ in range(40):
            mid = 0.5 * (left + right)
            feasible_mid, place_mid, weights_mid, rem_mid = pack_with_T(mid)
            if feasible_mid:
                right = mid
                best_place = place_mid
                best_weights = weights_mid
                best_rem = rem_mid
            else:
                left = mid
        placement = best_place

    # Prepare arrays for local search
    remaining = [GPU_MEM_SIZE for _ in range(gpu_num)]
    weights = [0.0 for _ in range(gpu_num)]
    for i in range(gpu_num):
        for m in placement[i]:
            s = next((s for (mm, s, _) in items if mm is m), getattr(m, 'model_size', 0))
            w = model_pressure(m)
            remaining[i] -= s
            if w != float('inf'):
                weights[i] += w
            else:
                weights[i] += 1e12  # extremely large to reflect impractical pressure

    # Local search improvement focused on reducing max KVPR
    def current_kvprs():
        return [kvpr(weights[i], remaining[i]) for i in range(gpu_num)]

    eps = 1e-12
    max_iters = max(10, 2 * len(models))
    for _ in range(max_iters):
        kvprs_now = current_kvprs()
        bottleneck_gpu = max(range(gpu_num), key=lambda i: kvprs_now[i])
        cur_max = kvprs_now[bottleneck_gpu]

        best_improvement = 0.0
        best_action = None  # ('move', src, dst, model) or ('swap', g1, g2, m1, m2)
        best_new_max = cur_max

        # Try single-model moves from bottleneck to other GPUs
        for m in list(placement[bottleneck_gpu]):
            w = model_pressure(m)
            if w == float('inf'):
                w = 1e12
            s = getattr(m, 'model_size', 0)
            for dst in range(gpu_num):
                if dst == bottleneck_gpu:
                    continue
                if s <= remaining[dst]:
                    tw = list(weights)
                    tr = list(remaining)
                    tw[bottleneck_gpu] -= w
                    tr[bottleneck_gpu] += s
                    tw[dst] += w
                    tr[dst] -= s
                    new_max = calc_max_kvpr(tw, tr)
                    improvement = cur_max - new_max
                    if (improvement > best_improvement + eps) or (
                        abs(improvement - best_improvement) <= eps and new_max < best_new_max - eps
                    ):
                        best_improvement = improvement
                        best_new_max = new_max
                        best_action = ('move', bottleneck_gpu, dst, m)

        # Try swaps between bottleneck and others
        for other in range(gpu_num):
            if other == bottleneck_gpu:
                continue
            for m1 in list(placement[bottleneck_gpu]):
                w1 = model_pressure(m1); w1 = w1 if w1 != float('inf') else 1e12
                s1 = getattr(m1, 'model_size', 0)
                for m2 in list(placement[other]):
                    w2 = model_pressure(m2); w2 = w2 if w2 != float('inf') else 1e12
                    s2 = getattr(m2, 'model_size', 0)
                    new_rem_b = remaining[bottleneck_gpu] + s1 - s2
                    new_rem_o = remaining[other] + s2 - s1
                    if new_rem_b >= 0 and new_rem_o >= 0:
                        tw = list(weights)
                        tr = list(remaining)
                        tw[bottleneck_gpu] = tw[bottleneck_gpu] - w1 + w2
                        tr[bottleneck_gpu] = new_rem_b
                        tw[other] = tw[other] - w2 + w1
                        tr[other] = new_rem_o
                        new_max = calc_max_kvpr(tw, tr)
                        improvement = cur_max - new_max
                        if (improvement > best_improvement + eps) or (
                            abs(improvement - best_improvement) <= eps and new_max < best_new_max - eps
                        ):
                            best_improvement = improvement
                            best_new_max = new_max
                            best_action = ('swap', bottleneck_gpu, other, m1, m2)

        if best_action is None or best_improvement <= eps:
            break  # no improvement found

        # Commit best action
        if best_action[0] == 'move':
            _, src, dst, m = best_action
            placement[src].remove(m)
            placement[dst].append(m)
            w = model_pressure(m); w = w if w != float('inf') else 1e12
            s = getattr(m, 'model_size', 0)
            weights[src] -= w
            remaining[src] += s
            weights[dst] += w
            remaining[dst] -= s
        else:
            _, g1, g2, m1, m2 = best_action
            placement[g1].remove(m1)
            placement[g2].remove(m2)
            placement[g1].append(m2)
            placement[g2].append(m1)
            w1 = model_pressure(m1); w1 = w1 if w1 != float('inf') else 1e12
            s1 = getattr(m1, 'model_size', 0)
            w2 = model_pressure(m2); w2 = w2 if w2 != float('inf') else 1e12
            s2 = getattr(m2, 'model_size', 0)
            weights[g1] = weights[g1] - w1 + w2
            weights[g2] = weights[g2] - w2 + w1
            remaining[g1] = remaining[g1] + s1 - s2
            remaining[g2] = remaining[g2] + s2 - s1

    return placement

# EVOLVE-BLOCK-END


if __name__ == "__main__":
    # Test the algorithm

    from evaluator import generate_test_gpu_models
    from evaluator import calculate_kvcache_pressure
    from evaluator import safe_float
    import numpy as np

    test_cases = generate_test_gpu_models()
    all_kvpr = []
    for i, (gpu_num, gpu_models) in enumerate(test_cases):

        results = compute_model_placement(gpu_num, gpu_models)
        max_kvpr = calculate_kvcache_pressure(results)
        all_kvpr.append(safe_float(max_kvpr))

    avg_kvpr = np.mean(all_kvpr)
    if avg_kvpr != 0:
        avg_kvpr = 1.0 / avg_kvpr

    print(f"Max KVPR: {avg_kvpr:.3f}")