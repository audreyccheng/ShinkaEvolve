GPU_MEM_SIZE = 80 # GB

# EVOLVE-BLOCK-START

def compute_model_placement(gpu_num, models):
    """
    Compute a model placement that minimizes the maximum KVPR across all GPUs.

    KVPR(GPU i) = sum_j (req_rate_j / slo_j) / (GPU_MEM_SIZE - sum_j(model_size_j))
    If remaining memory is 0 or less, KVPR is treated as infinity.

    Args:
        gpu_num: Number of GPUs
        models: List of models to place

    Returns:
        A placement dict: {gpu_id: [Model, ...]}
    """

    # Helpers
    def kvpr(weight, rem_mem):
        return float('inf') if rem_mem <= 0 else (weight / rem_mem)

    def max_kvpr(weights, rems):
        max_val = 0.0
        for i in range(len(weights)):
            v = kvpr(weights[i], rems[i])
            if v > max_val:
                max_val = v
        return max_val

    # Sort models: primary by pressure w = req_rate/slo desc, secondary by size desc
    def model_pressure(m):
        return (m.req_rate / m.slo) if m.slo != 0 else float('inf')

    sorted_models = sorted(
        models,
        key=lambda m: (model_pressure(m), m.model_size),
        reverse=True
    )

    # Initialize states
    placement = {i: [] for i in range(gpu_num)}
    remaining = [GPU_MEM_SIZE for _ in range(gpu_num)]
    weights = [0.0 for _ in range(gpu_num)]

    # Greedy placement with look-ahead (minimize future global max KVPR)
    for m in sorted_models:
        w = model_pressure(m)
        s = m.model_size

        best_choice = None  # (future_max_kvpr, tie1, tie2, tie3, gpu_id)
        for i in range(gpu_num):
            if s <= remaining[i]:
                new_rem_i = remaining[i] - s
                new_w_i = weights[i] + w

                # Compute resulting max KVPR after placing on GPU i
                fut_max = 0.0
                for j in range(gpu_num):
                    if j == i:
                        v = kvpr(new_w_i, new_rem_i)
                    else:
                        v = kvpr(weights[j], remaining[j])
                    if v > fut_max:
                        fut_max = v

                # Tie-breaking: prefer more remaining memory after placement, then smaller current load, then lower GPU id
                tie1 = -new_rem_i  # smaller is better -> more remaining memory
                tie2 = weights[i]  # smaller load preferred
                tie3 = i           # stable deterministic choice
                candidate = (fut_max, tie1, tie2, tie3, i)

                if best_choice is None or candidate < best_choice:
                    best_choice = candidate

        if best_choice is None:
            raise ValueError(
                f"Unable to place model of size {s} GB on any GPU. "
                f"Remaining per-GPU memory: {remaining}"
            )

        _, _, _, _, chosen = best_choice
        placement[chosen].append(m)
        weights[chosen] += w
        remaining[chosen] -= s

    # Local search improvement: single moves and pairwise swaps from bottleneck GPU
    def current_kvprs():
        return [kvpr(weights[i], remaining[i]) for i in range(gpu_num)]

    eps = 1e-12
    max_iters = max(10, 2 * len(models))
    for _ in range(max_iters):
        kvprs_now = current_kvprs()
        bottleneck_gpu = max(range(gpu_num), key=lambda i: kvprs_now[i])
        cur_max = kvprs_now[bottleneck_gpu]

        best_improvement = 0.0
        best_action = None  # ('move', src, dst, model) or ('swap', g1, g2, m1, m2)
        best_new_max = cur_max

        # Try single-model moves from bottleneck to other GPUs
        for m in placement[bottleneck_gpu]:
            w = model_pressure(m)
            s = m.model_size
            for dst in range(gpu_num):
                if dst == bottleneck_gpu:
                    continue
                if s <= remaining[dst]:
                    # simulate
                    tw = list(weights)
                    tr = list(remaining)
                    tw[bottleneck_gpu] -= w
                    tr[bottleneck_gpu] += s
                    tw[dst] += w
                    tr[dst] -= s
                    new_max = max_kvpr(tw, tr)
                    improvement = cur_max - new_max
                    if (improvement > best_improvement + eps) or (
                        abs(improvement - best_improvement) <= eps and new_max < best_new_max - eps
                    ):
                        best_improvement = improvement
                        best_new_max = new_max
                        best_action = ('move', bottleneck_gpu, dst, m)

        # Try swaps between bottleneck and others
        for other in range(gpu_num):
            if other == bottleneck_gpu:
                continue
            for m1 in placement[bottleneck_gpu]:
                w1 = model_pressure(m1)
                s1 = m1.model_size
                for m2 in placement[other]:
                    w2 = model_pressure(m2)
                    s2 = m2.model_size
                    # Check memory feasibility after swap
                    new_rem_b = remaining[bottleneck_gpu] + s1 - s2
                    new_rem_o = remaining[other] + s2 - s1
                    if new_rem_b >= 0 and new_rem_o >= 0:
                        tw = list(weights)
                        tr = list(remaining)
                        tw[bottleneck_gpu] = tw[bottleneck_gpu] - w1 + w2
                        tr[bottleneck_gpu] = new_rem_b
                        tw[other] = tw[other] - w2 + w1
                        tr[other] = new_rem_o
                        new_max = max_kvpr(tw, tr)
                        improvement = cur_max - new_max
                        if (improvement > best_improvement + eps) or (
                            abs(improvement - best_improvement) <= eps and new_max < best_new_max - eps
                        ):
                            best_improvement = improvement
                            best_new_max = new_max
                            best_action = ('swap', bottleneck_gpu, other, m1, m2)

        if best_action is None or best_improvement <= eps:
            break  # no improvement found

        # Commit best action
        if best_action[0] == 'move':
            _, src, dst, m = best_action
            placement[src].remove(m)
            placement[dst].append(m)
            w = model_pressure(m)
            s = m.model_size
            weights[src] -= w
            remaining[src] += s
            weights[dst] += w
            remaining[dst] -= s
        else:
            _, g1, g2, m1, m2 = best_action
            placement[g1].remove(m1)
            placement[g2].remove(m2)
            placement[g1].append(m2)
            placement[g2].append(m1)
            w1 = model_pressure(m1); s1 = m1.model_size
            w2 = model_pressure(m2); s2 = m2.model_size
            weights[g1] = weights[g1] - w1 + w2
            weights[g2] = weights[g2] - w2 + w1
            remaining[g1] = remaining[g1] + s1 - s2
            remaining[g2] = remaining[g2] + s2 - s1

    return placement

# EVOLVE-BLOCK-END


if __name__ == "__main__":
    # Test the algorithm

    from evaluator import generate_test_gpu_models
    from evaluator import calculate_kvcache_pressure
    from evaluator import safe_float
    import numpy as np

    test_cases = generate_test_gpu_models()
    all_kvpr = []
    for i, (gpu_num, gpu_models) in enumerate(test_cases):

        results = compute_model_placement(gpu_num, gpu_models)
        max_kvpr = calculate_kvcache_pressure(results)
        all_kvpr.append(safe_float(max_kvpr))

    avg_kvpr = np.mean(all_kvpr)
    if avg_kvpr != 0:
        avg_kvpr = 1.0 / avg_kvpr


    print(f"Max KVPR: {avg_kvpr:.3f}")